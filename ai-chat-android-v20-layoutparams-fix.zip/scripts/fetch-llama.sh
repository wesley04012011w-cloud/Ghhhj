#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LLAMA_DIR="$ROOT/app/src/main/cpp/llama.cpp"

# Current upstream release tag. Override with LLAMA_REF if desired.
LLAMA_REF="${LLAMA_REF:-b10941}"

rm -rf "$LLAMA_DIR"
git clone --depth 1 --branch "$LLAMA_REF" \
  https://github.com/ggml-org/llama.cpp "$LLAMA_DIR"
