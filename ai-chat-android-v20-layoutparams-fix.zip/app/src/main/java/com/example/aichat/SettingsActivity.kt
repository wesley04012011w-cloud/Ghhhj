package com.example.aichat

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.roundToInt

class SettingsActivity : Activity() {
    private val bg = Color.rgb(10, 10, 10)
    private val surface = Color.rgb(20, 20, 20)
    private val surface2 = Color.rgb(28, 28, 28)
    private val border = Color.rgb(48, 48, 48)
    private val white = Color.rgb(245, 245, 245)
    private val muted = Color.rgb(150, 150, 150)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int = 12): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), border)
        }

    private fun label(text: String, size: Float = 14f, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(if (bold) white else muted)
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }

    private fun section(title: String, subtitle: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            setBackground(bg(surface))
        }
        box.addView(label(title, 16f, true))
        box.addView(label(subtitle, 12f))
        return box
    }

    private fun addRow(parent: LinearLayout, title: String, desc: String, control: View) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, dp(9))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 14f, true))
        texts.addView(label(desc, 11f))
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(control, LinearLayout.LayoutParams(dp(145), dp(48)))
        parent.addView(row)
    }

    private fun spinner(items: Array<String>, selected: Int): Spinner =
        Spinner(this).apply {
            adapter = ArrayAdapter(
                this@SettingsActivity,
                android.R.layout.simple_spinner_dropdown_item,
                items
            )
            setSelection(selected.coerceIn(items.indices))
            setBackground(bg(surface2))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }

        val s = EngineSettings.from(this)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(
                dp(16),
                bars.top + dp(12),
                dp(16),
                maxOf(bars.bottom, ime.bottom) + dp(24)
            )
            insets
        }
        ViewCompat.requestApplyInsets(scroll)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
        }
        scroll.addView(root)

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 34f
            setTextColor(white)
            gravity = Gravity.CENTER
            setBackground(bg(surface2))
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val title = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        title.addView(label("Configurações", 21f, true))
        title.addView(label("llama.cpp • aplicado ao carregar o modelo", 12f))
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)

        val note = label(
            "As opções marcadas como reinicialização exigem recarregar o GGUF. " +
                    "Os valores ficam salvos neste aparelho.",
            12f
        )
        note.setPadding(dp(4), 0, dp(4), dp(14))
        root.addView(note)

        // Context / execution
        val ctxBox = section("Contexto e execução", "Memória, lote e CPU")
        val contexts = arrayOf("1024", "2048", "4096", "8192", "16384", "32768")
        val ctxSpinner = spinner(contexts, contexts.indexOf(s.contextSize.toString()).coerceAtLeast(0))
        addRow(ctxBox, "Contexto (tokens)", "Quanto histórico o contexto pode comportar.", ctxSpinner)

        val batches = arrayOf("128", "256", "512", "1024", "2048")
        val batchSpinner = spinner(batches, batches.indexOf(s.batchSize.toString()).coerceAtLeast(0))
        addRow(ctxBox, "Batch", "Tamanho máximo do processamento do prompt.", batchSpinner)

        val threadItems = arrayOf("Auto", "1", "2", "3", "4", "6", "8")
        val threadSpinner = spinner(threadItems, threadItems.indexOf(if (s.threads == 0) "Auto" else s.threads.toString()))
        addRow(ctxBox, "Threads CPU", "0 = deixa o llama.cpp escolher.", threadSpinner)
        root.addView(ctxBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        // KV / attention
        val kvBox = section("KV cache e atenção", "Economize RAM ou priorize precisão")
        val kvs = arrayOf("F16", "Q8_0", "Q4_0")
        val kvSpinner = spinner(kvs, kvs.indexOf(s.kvType).coerceAtLeast(0))
        addRow(kvBox, "Tipo KV", "K e V: F16, Q8_0 ou Q4_0.", kvSpinner)

        val flashItems = arrayOf("Auto", "Ligado", "Desligado")
        val flashIndex = when (s.flashAttention) { 1 -> 1; 0 -> 2; else -> 0 }
        val flashSpinner = spinner(flashItems, flashIndex)
        addRow(kvBox, "Flash Attention", "Otimização do cálculo da atenção.", flashSpinner)

        val mmap = Switch(this).apply {
            isChecked = s.mmap
            text = "MMAP"
            textSize = 12f
            setTextColor(white)
        }
        addRow(kvBox, "Carregamento MMAP", "Mapeia o GGUF em vez de carregar tudo de uma vez.", mmap)
        root.addView(kvBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        // Sampling
        val sampleBox = section("Geração", "Parâmetros de amostragem")
        val tempLabel = label("Temperatura  %.2f".format(java.util.Locale.US, s.temperature), 14f, true)
        val tempSeek = SeekBar(this).apply {
            max = 200
            progress = (s.temperature.coerceIn(0f, 2f) * 100f).roundToInt()
        }
        tempSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                tempLabel.text = "Temperatura  %.2f".format(java.util.Locale.US, p / 100f)
            }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        sampleBox.addView(tempLabel)
        sampleBox.addView(tempSeek, LinearLayout.LayoutParams(-1, dp(44)))

        val topK = EditText(this).apply {
            setText(s.topK.toString()); textSize = 14f; setTextColor(white); setSelectAllOnFocus(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER; setBackground(bg(surface2))
        }
        val topP = EditText(this).apply {
            setText(s.topP.toString()); textSize = 14f; setTextColor(white); setSelectAllOnFocus(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setBackground(bg(surface2))
        }
        val minP = EditText(this).apply {
            setText(s.minP.toString()); textSize = 14f; setTextColor(white); setSelectAllOnFocus(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setBackground(bg(surface2))
        }
        val repeat = EditText(this).apply {
            setText(s.repeatPenalty.toString()); textSize = 14f; setTextColor(white); setSelectAllOnFocus(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setBackground(bg(surface2))
        }
        val repeatN = EditText(this).apply {
            setText(s.repeatLastN.toString()); textSize = 14f; setTextColor(white); setSelectAllOnFocus(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER; setBackground(bg(surface2))
        }
        val maxTokens = EditText(this).apply {
            setText(s.maxTokens.toString()); textSize = 14f; setTextColor(white); setSelectAllOnFocus(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER; setBackground(bg(surface2))
        }
        addRow(sampleBox, "Top-K", "0 desativa.", topK)
        addRow(sampleBox, "Top-P", "1.0 desativa.", topP)
        addRow(sampleBox, "Min-P", "0 desativa.", minP)
        addRow(sampleBox, "Repetição", "1.0 desativa a penalidade.", repeat)
        addRow(sampleBox, "Repeat last N", "Tokens anteriores usados na penalidade.", repeatN)
        addRow(sampleBox, "Máx. tokens", "Limite de tokens gerados por resposta.", maxTokens)
        root.addView(sampleBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        // Jinja / reasoning
        val chatBox = section("Template de conversa", "Como o prompt é montado pelo llama.cpp")
        val jinja = Switch(this).apply {
            isChecked = s.useJinja
            text = "Usar Jinja do GGUF"
            textSize = 12f
            setTextColor(white)
        }
        addRow(chatBox, "Chat template", "Usa o template Jinja gravado nos metadados do GGUF.", jinja)

        val thinking = Switch(this).apply {
            isChecked = s.enableThinking
            text = "Thinking / reasoning"
            textSize = 12f
            setTextColor(white)
        }
        addRow(chatBox, "Raciocínio", "Envia enable_thinking=true para o Jinja quando o modelo suportar.", thinking)
        root.addView(chatBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        // Seed
        val seedBox = section("Aleatoriedade", "Seed fixa ou aleatória")
        val seed = EditText(this).apply {
            setText(if (s.seed < 0) "-1" else s.seed.toString())
            textSize = 14f; setTextColor(white); setSelectAllOnFocus(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setBackground(bg(surface2))
        }
        addRow(seedBox, "Seed", "-1 usa uma seed aleatória a cada geração.", seed)
        root.addView(seedBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val save = Button(this).apply {
            text = "SALVAR CONFIGURAÇÕES"
            textSize = 13f
            setTextColor(Color.BLACK)
            setBackground(bg(white, 14))
        }
        root.addView(save, LinearLayout.LayoutParams(-1, dp(52)))

        save.setOnClickListener {
            try {
                val contextValue = contexts[ctxSpinner.selectedItemPosition].toInt()
                val batchValue = batches[batchSpinner.selectedItemPosition].toInt().coerceAtMost(contextValue)
                val threadsValue = if (threadSpinner.selectedItemPosition == 0) 0
                else threadItems[threadSpinner.selectedItemPosition].toInt()
                val flashValue = when (flashSpinner.selectedItemPosition) {
                    1 -> 1
                    2 -> 0
                    else -> -1
                }

                val newSettings = EngineSettings(
                    contextSize = contextValue,
                    batchSize = batchValue,
                    threads = threadsValue,
                    mmap = mmap.isChecked,
                    flashAttention = flashValue,
                    kvType = kvs[kvSpinner.selectedItemPosition],
                    temperature = (tempSeek.progress / 100f).coerceIn(0f, 2f),
                    topK = topK.text.toString().toInt().coerceAtLeast(0),
                    topP = topP.text.toString().toFloat().coerceIn(0f, 1f),
                    minP = minP.text.toString().toFloat().coerceIn(0f, 1f),
                    repeatPenalty = repeat.text.toString().toFloat().coerceAtLeast(0f),
                    repeatLastN = repeatN.text.toString().toInt().coerceAtLeast(0),
                    maxTokens = maxTokens.text.toString().toInt().coerceIn(1, 8192),
                    seed = seed.text.toString().toLong(),
                    useJinja = jinja.isChecked,
                    enableThinking = thinking.isChecked
                )
                EngineSettings.save(this, newSettings)
                setResult(RESULT_OK, Intent().putExtra("settings_changed", true))
                Toast.makeText(this, "Configurações salvas.", Toast.LENGTH_SHORT).show()
                finish()
            } catch (e: Exception) {
                Toast.makeText(this, "Revise os valores preenchidos.", Toast.LENGTH_SHORT).show()
            }
        }

        setContentView(scroll)
    }
}
