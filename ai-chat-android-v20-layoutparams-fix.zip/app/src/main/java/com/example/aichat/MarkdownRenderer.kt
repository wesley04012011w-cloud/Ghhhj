package com.example.aichat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.graphics.Color
import android.graphics.Typeface
import android.text.Html
import android.text.Spanned
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.regex.Pattern

/** Lightweight Markdown renderer with real code-block cards and copy buttons. */
object MarkdownRenderer {
    private data class Segment(val code: Boolean, val language: String = "", val text: String)

    fun render(text: String): Spanned {
        // Used for ordinary text (and the thinking panel). Code fences are rendered
        // by renderInto(), where we can create a real code card.
        return Html.fromHtml(renderInlineHtml(text), Html.FROM_HTML_MODE_LEGACY)
    }

    fun apply(view: TextView, text: String) {
        view.text = render(text)
    }

    /** Render a message as normal Markdown plus independent code cards. */
    fun renderInto(container: LinearLayout, text: String, codeBackground: Int = Color.rgb(8, 8, 8), textColor: Int = Color.rgb(245, 245, 245)) {
        container.removeAllViews()
        val segments = splitFenced(text)
        segments.forEach { segment ->
            if (segment.code) {
                addCodeCard(container, segment.language, segment.text, codeBackground, textColor)
            } else if (segment.text.isNotEmpty()) {
                val tv = TextView(container.context).apply {
                    textSize = 15f
                    setTextColor(textColor)
                    setLineSpacing(0f, 1.12f)
                    includeFontPadding = true
                    this.text = render(segment.text)
                    setPadding(0, 0, 0, 0)
                }
                container.addView(tv, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(container, 4)
                })
            }
        }
        if (container.childCount == 0) {
            container.addView(TextView(container.context).apply { this.text = "" })
        }
    }

    private fun addCodeCard(parent: LinearLayout, language: String, code: String, background: Int, textColor: Int) {
        val context = parent.context
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this, 11), dp(this, 8), dp(this, 11), dp(this, 10))
            setBackground(roundRect(background, dp(this, 10)))
        }

        val header = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        val langView = TextView(context).apply {
            text = language.ifBlank { "código" }.lowercase()
            textSize = 11f
            setTextColor(Color.rgb(175, 175, 175))
            setPadding(dp(this, 4), dp(this, 2), dp(this, 4), dp(this, 2))
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        header.addView(langView, LinearLayout.LayoutParams(0, -2, 1f))

        val copy = TextView(context).apply {
            text = "Copiar"
            textSize = 11f
            setTextColor(Color.rgb(190, 190, 190))
            setPadding(dp(this, 10), dp(this, 5), dp(this, 10), dp(this, 5))
            setBackground(roundRect(Color.rgb(28, 28, 28), dp(this, 7)))
            setOnClickListener {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("código", code))
                Toast.makeText(context, "Código copiado", Toast.LENGTH_SHORT).show()
            }
        }
        header.addView(copy, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(header, 6) })

        val download = TextView(context).apply {
            text = "Baixar"
            textSize = 11f
            setTextColor(Color.rgb(190, 190, 190))
            setPadding(dp(this, 10), dp(this, 5), dp(this, 10), dp(this, 5))
            setBackground(roundRect(Color.rgb(28, 28, 28), dp(this, 7)))
            setOnClickListener { saveCode(context, language, code) }
        }
        header.addView(download, LinearLayout.LayoutParams(-2, -2))
        card.addView(header, LinearLayout.LayoutParams(-1, -2))

        val codeView = TextView(context).apply {
            this.text = code.trimEnd()
            textSize = 13f
            setTextColor(textColor)
            typeface = Typeface.MONOSPACE
            setLineSpacing(0f, 1.05f)
            includeFontPadding = true
            setPadding(0, dp(this, 9), 0, 0)
            setTextIsSelectable(true)
        }
        val scroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = false
            addView(codeView, android.widget.FrameLayout.LayoutParams(-2, -2))
        }
        card.addView(scroll, LinearLayout.LayoutParams(-1, -2))

        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(parent, 4)
            bottomMargin = dp(parent, 8)
        })
    }

    private fun saveCode(context: Context, language: String, code: String) {
        val ext = extensionFor(language)
        val mime = mimeFor(ext)
        val fileName = "codigo.$ext"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("não consegui criar o arquivo")
                try {
                    resolver.openOutputStream(uri)?.use { it.write(code.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("não consegui gravar o arquivo")
                    resolver.update(uri, ContentValues().apply {
                        put(MediaStore.Downloads.IS_PENDING, 0)
                    }, null, null)
                } catch (e: Exception) {
                    resolver.delete(uri, null, null)
                    throw e
                }
                Toast.makeText(context, "Salvo em Downloads/$fileName", Toast.LENGTH_LONG).show()
            } else {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = mime
                    putExtra(Intent.EXTRA_TITLE, fileName)
                }
                if (context is android.app.Activity) {
                    context.startActivityForResult(intent, 9012)
                } else {
                    throw IllegalStateException("não consegui abrir o seletor")
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Falha ao baixar: ${e.message ?: "erro desconhecido"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun extensionFor(language: String): String = when (language.lowercase()) {
        "html", "htm" -> "html"
        "css" -> "css"
        "js", "javascript" -> "js"
        "ts", "typescript" -> "ts"
        "json" -> "json"
        "xml" -> "xml"
        "kotlin", "kt" -> "kt"
        "java" -> "java"
        "python", "py" -> "py"
        "c" -> "c"
        "cpp", "c++" -> "cpp"
        "h" -> "h"
        "hpp" -> "hpp"
        "bash", "sh", "shell" -> "sh"
        "sql" -> "sql"
        "markdown", "md" -> "md"
        "yaml", "yml" -> "yml"
        "toml" -> "toml"
        "rust", "rs" -> "rs"
        "go" -> "go"
        else -> "txt"
    }

    private fun mimeFor(ext: String): String = when (ext) {
        "html" -> "text/html"
        "css" -> "text/css"
        "js", "ts" -> "text/javascript"
        "json" -> "application/json"
        "xml" -> "application/xml"
        else -> "text/plain"
    }

    private fun splitFenced(source: String): List<Segment> {
        val text = source.replace("\r\n", "\n").replace('\r', '\n')
        val result = mutableListOf<Segment>()
        val lines = text.split("\n")
        val normal = StringBuilder()
        var inCode = false
        var language = ""
        val code = StringBuilder()

        fun flushNormal() {
            if (normal.isNotEmpty()) {
                result += Segment(false, text = normal.toString())
                normal.clear()
            }
        }

        for (line in lines) {
            val trimmed = line.trimStart()
            if (!inCode && trimmed.startsWith("```") ) {
                flushNormal()
                language = trimmed.removePrefix("```").trim().lowercase()
                code.clear()
                inCode = true
            } else if (inCode && trimmed.trim() == "```") {
                result += Segment(true, language, code.toString())
                language = ""
                code.clear()
                inCode = false
            } else if (inCode) {
                if (code.isNotEmpty()) code.append('\n')
                code.append(line)
            } else {
                if (normal.isNotEmpty()) normal.append('\n')
                normal.append(line)
            }
        }

        // Models occasionally hit max_tokens before emitting the closing fence.
        // Still render the whole remainder as code instead of leaking raw fences.
        if (inCode) result += Segment(true, language, code.toString())
        flushNormal()
        return result
    }

    private fun renderInlineHtml(text: String): String {
        var source = text.replace("\r\n", "\n").replace('\r', '\n')
        val inline = mutableListOf<String>()
        val matcher = Pattern.compile("`([^`\\n]+)`").matcher(source)
        val sb = StringBuffer()
        while (matcher.find()) {
            inline += matcher.group(1).orEmpty()
            matcher.appendReplacement(sb, "§§INLINE${inline.lastIndex}§§")
        }
        matcher.appendTail(sb)
        source = sb.toString()
        var s = escapeHtml(source)
        s = s.replace(Regex("(?m)^###### (.+)$"), "<b><small>$1</small></b>")
            .replace(Regex("(?m)^##### (.+)$"), "<b>$1</b>")
            .replace(Regex("(?m)^#### (.+)$"), "<b>$1</b>")
            .replace(Regex("(?m)^### (.+)$"), "<b><big>$1</big></b>")
            .replace(Regex("(?m)^## (.+)$"), "<b><big>$1</big></b>")
            .replace(Regex("(?m)^# (.+)$"), "<b><big>$1</big></b>")
            .replace(Regex("(?m)^\\s*[-*] (.+)$"), "• $1")
            .replace(Regex("(?m)^\\s*(\\d+)\\. (.+)$"), "$1. $2")
            .replace(Regex("(?m)^&gt; ?(.+)$"), "<font color=\"#A0A0A0\">▌ $1</font>")
            .replace(Regex("\\*\\*([^*]+)\\*\\*|__([^_]+)__")) { m ->
                "<b>${m.groupValues[1].ifEmpty { m.groupValues[2] }}</b>"
            }
            .replace(Regex("~~([^~]+)~~"), "<s>$1</s>")
            .replace(Regex("(?<!\\*)\\*([^*]+)\\*(?!\\*)|(?<!_)_([^_]+)_(?!_)")) { m ->
                "<i>${m.groupValues[1].ifEmpty { m.groupValues[2] }}</i>"
            }
        s = s.replace("\n", "<br>")
        inline.forEachIndexed { index, code ->
            s = s.replace("§§INLINE$index§§", "<font color=\"#E8E8E8\"><tt>${escapeHtml(code)}</tt></font>")
        }
        return s
    }

    private fun escapeHtml(text: String): String =
        text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun dp(view: View, value: Int): Int = (value * view.resources.displayMetrics.density).toInt()

    private fun roundRect(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
}
