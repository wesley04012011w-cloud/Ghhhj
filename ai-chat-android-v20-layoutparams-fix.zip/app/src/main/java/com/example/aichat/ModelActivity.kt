package com.example.aichat

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

class ModelActivity : Activity() {
    private val bg = Color.rgb(10,10,10)
    private val surface = Color.rgb(20,20,20)
    private val surface2 = Color.rgb(28,28,28)
    private val border = Color.rgb(48,48,48)
    private val white = Color.rgb(245,245,245)
    private val muted = Color.rgb(150,150,150)

    private data class ModelDef(
        val id: String,
        val name: String,
        val description: String,
        val fileName: String,
        val url: String,
        val sizeText: String,
        val thinking: Boolean
    )

    private val models = listOf(
        ModelDef(
            "smollm360",
            "SmolLM 360M Instruct",
            "Muito leve • chat geral",
            "SmolLM-360M-Instruct-Q4_K_M.gguf",
            "https://huggingface.co/second-state/SmolLM-360M-Instruct-GGUF/resolve/main/SmolLM-360M-Instruct-Q4_K_M.gguf?download=true",
            "≈271 MB",
            false
        ),
        ModelDef(
            "qwen25",
            "Qwen2.5 0.5B Instruct",
            "Leve • bom para português",
            "Qwen2.5-0.5B-Instruct-Q4_K_M.gguf",
            "https://huggingface.co/second-state/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf?download=true",
            "≈398 MB",
            false
        ),
        ModelDef(
            "qwen3",
            "Qwen3 0.6B",
            "Leve • suporte a thinking",
            "Qwen3-0.6B-Q4_K_M.gguf",
            "https://huggingface.co/second-state/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q4_K_M.gguf?download=true",
            "≈484 MB",
            true
        )
    )

    private lateinit var list: LinearLayout
    private var loadedPath: String? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadedPath = intent.getStringExtra("loaded_path")
        build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 12) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), border)
    }
    private fun tv(t: String, size: Float, color: Int = white, bold: Boolean = false) =
        TextView(this).apply {
            text=t; textSize=size; setTextColor(color)
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        scroll.addView(inner)

        val header = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val back = tv("‹",34f).apply {
            gravity=Gravity.CENTER; setBackground(bg(surface2))
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(48),dp(48)))
        val title = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(12),0,0,0)
        }
        title.addView(tv("Modelos",21f,white,true))
        title.addView(tv("Baixe, importe e gerencie seus GGUF",12f,muted))
        header.addView(title, LinearLayout.LayoutParams(0,-2,1f))
        inner.addView(header, LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(14)})

        val import = tv("📁  Importar GGUF do armazenamento",13f,white,true).apply {
            gravity=Gravity.CENTER; setBackground(bg(surface2))
            setOnClickListener { if(!busy) pickImport() }
        }
        inner.addView(import, LinearLayout.LayoutParams(-1,dp(48)).apply{bottomMargin=dp(14)})

        val localTitle = tv("Disponíveis neste aparelho",15f,white,true)
        inner.addView(localTitle, LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        inner.addView(list)

        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        models.forEach { addModelCard(it) }

        val dir = File(filesDir, "models")
        val known = models.map { it.fileName }.toSet()
        dir.listFiles()?.filter { it.isFile && it.extension.lowercase() == "gguf" && it.name !in known }
            ?.forEach { addLocalCard(it) }
    }

    private fun addModelCard(m: ModelDef) {
        val card = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12))
            setBackground(bg(surface))
        }
        val titleRow = LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val title = LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        title.addView(tv(m.name,16f,white,true))
        title.addView(tv("${m.description} • ${m.sizeText}${if(m.thinking) " • thinking" else ""}",11f,muted))
        titleRow.addView(title,LinearLayout.LayoutParams(0,-2,1f))
        card.addView(titleRow)

        val file = File(filesDir,"models/${m.fileName}")
        if (file.exists()) {
            val loaded = loadedPath == file.absolutePath
            val info = tv(if(loaded) "✓ Carregado" else "✓ Baixado",11f,muted).apply {
                setPadding(0,dp(7),0,dp(5))
            }
            card.addView(info)
            val button = tv(if(loaded) "Descarregar" else "Carregar",12f,white,true).apply {
                gravity=Gravity.CENTER; setBackground(bg(if(loaded) surface2 else white))
                if(!loaded) setTextColor(Color.BLACK)
                setOnClickListener {
                    val result=Intent().putExtra(if(loaded) "unload" else "model_path", file.absolutePath)
                    setResult(RESULT_OK,result); finish()
                }
            }
            card.addView(button,LinearLayout.LayoutParams(-1,dp(42)))
        } else {
            val progress = ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply {
                max=100; visibility=View.GONE
            }
            card.addView(progress,LinearLayout.LayoutParams(-1,dp(6)).apply{topMargin=dp(10);bottomMargin=dp(8)})
            val button = tv("Baixar",12f,white,true).apply {
                gravity=Gravity.CENTER; setBackground(bg(surface2))
                setOnClickListener { download(m, progress, this) }
            }
            card.addView(button,LinearLayout.LayoutParams(-1,dp(42)))
        }
        list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})
    }

    private fun addLocalCard(file: File) {
        val card=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));setBackground(bg(surface))
        }
        card.addView(tv(file.name,15f,white,true))
        card.addView(tv("GGUF local • ${file.length()/1024/1024} MB",11f,muted))
        val loaded=file.absolutePath==loadedPath
        val b=tv(if(loaded) "Descarregar" else "Carregar",12f,white,true).apply{
            gravity=Gravity.CENTER;setBackground(bg(surface2))
            setOnClickListener{
                setResult(RESULT_OK,Intent().putExtra(if(loaded)"unload" else "model_path",file.absolutePath));finish()
            }
        }
        card.addView(b,LinearLayout.LayoutParams(-1,dp(42)).apply{topMargin=dp(9)})
        list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})
    }

    private fun download(m: ModelDef, progress: ProgressBar, button: TextView) {
        if(busy)return
        busy=true
        button.isEnabled=false
        button.text="Baixando…"
        progress.visibility=View.VISIBLE
        Thread {
            val target=File(filesDir,"models/${m.fileName}")
            target.parentFile?.mkdirs()
            val temp=File(target.absolutePath+".part")
            try {
                val conn=(URL(m.url).openConnection() as HttpURLConnection).apply{
                    connectTimeout=15000;readTimeout=30000;instanceFollowRedirects=true
                    requestMethod="GET"
                }
                conn.connect()
                if(conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
                val total=conn.contentLengthLong
                var done=0L
                conn.inputStream.use { input ->
                    FileOutputStream(temp).use { output ->
                        val buffer=ByteArray(1024*1024)
                        while(true){
                            val n=input.read(buffer)
                            if(n<=0)break
                            output.write(buffer,0,n);done+=n
                            val pct=if(total>0) (done*100/total).toInt() else -1
                            runOnUiThread {
                                if(pct>=0) progress.progress=pct
                                button.text=if(total>0) "${done/1024/1024} / ${total/1024/1024} MB" else "Baixando…"
                            }
                        }
                    }
                }
                if(!temp.renameTo(target)) throw IllegalStateException("Não consegui finalizar o arquivo.")
                runOnUiThread { busy=false; refresh() }
            } catch(e:Exception) {
                temp.delete()
                runOnUiThread {
                    busy=false; button.isEnabled=true; button.text="Tentar novamente"
                    Toast.makeText(this,e.message ?: "Falha no download.",Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun pickImport() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE)
        },100)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=100 || resultCode!=RESULT_OK)return
        val uri=data?.data ?: return
        Thread {
            try {
                val name=queryName(uri) ?: "model.gguf"
                require(name.lowercase().endsWith(".gguf")){"Selecione um arquivo .gguf."}
                val dst=File(filesDir,"models/$name")
                dst.parentFile?.mkdirs()
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input){"Não consegui abrir o arquivo."}
                    FileOutputStream(dst).use { output -> input.copyTo(output,1024*1024) }
                }
                runOnUiThread { Toast.makeText(this,"Modelo copiado para a pasta do app.",Toast.LENGTH_SHORT).show();refresh() }
            } catch(e:Exception) {
                runOnUiThread { Toast.makeText(this,e.message ?: "Falha ao importar.",Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun queryName(uri:Uri):String?{
        contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use{
            if(it.moveToFirst())return it.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }
}
