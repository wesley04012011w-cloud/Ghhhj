# AI Chat Android — v0.4

Chat local Android com `llama.cpp` + GGUF.

## O que mudou nesta versão

- UI dark sem exagero de cores.
- Conteúdo respeita status bar, navigation bar e IME/teclado via WindowInsets.
- Composer continua visível quando o teclado Samsung/Android abre.
- Menu lateral com conversas e acesso a **Configurações da engine**.
- Configurações persistentes:
  - contexto;
  - batch;
  - threads CPU;
  - MMAP;
  - Flash Attention;
  - tipo de KV cache (F16/Q8_0/Q4_0);
  - temperatura;
  - Top-K;
  - Top-P;
  - Min-P;
  - repetição;
  - repeat-last-N;
  - máximo de tokens;
  - seed.
- Alterações de engine são aplicadas ao recarregar o modelo.
- Streaming e chat template do GGUF continuam ativos.

As opções de contexto, KV cache e Flash Attention correspondem aos parâmetros atuais expostos pelo `llama.cpp`; tipos KV quantizados exigem Flash Attention. A documentação upstream também expõe batch, threads, temperatura, Top-K, Top-P, Min-P e penalidade de repetição como parâmetros de execução. 


V9: chat templates agora usam a camada common_chat do llama.cpp com Jinja e enable_thinking=true; o parser de reasoning usa as tags detectadas pelo template. Defaults de amostragem foram ajustados para 0.6 / top-k 20 / min-p 0.0.


V9: corrige o estado inicial do parser de thinking quando o template já injeta `<think>` no prompt, remove o overload legado do chat template, aumenta o buffer de peça de token e deixa a penalidade de repetição desligada por padrão (1.0).

V10 fixes UTF-8 token chunks crossing JNI boundaries and strengthens Qwen3 reasoning tag detection.


V15: corrige double-escape de blocos de código Markdown (agora `<html>` aparece como código, não como `&lt;html&gt;`), protege código inline antes do parser Markdown, usa `preserve_reasoning` correto no common_chat do llama.cpp, detecta tags de reasoning também pela origem do template e ativa `/think` por turno apenas em templates Jinja com o padrão de reasoning do Qwen3.


## V15 fixes
- Thinking is rendered in a separate collapsible panel above the answer bubble.
- Jinja thinking mode can prefill the model's thinking start tag when the template supports reasoning but does not prefill it itself.
- Markdown fenced code blocks are rendered as dedicated code cards with language labels and a Copy button.
- Unterminated code fences caused by max-token truncation are still rendered as code.


V18: JNI thinking callbacks are concrete/abstract rather than Kotlin default interface methods; reasoning router catches <think>, <thinking>, <reasoning>, and <analysis> tags even when llama.cpp does not report them; detected start tags trigger the thinking UI immediately.

V32: reverted the custom ShimmerEditText composer to standard EditText and posts send action to UI queue for device stability; keeps compact icon composer.

V33: add missing vector drawables used by the modern composer; fixes compileReleaseKotlin R.drawable.ic_add/ic_send errors.
