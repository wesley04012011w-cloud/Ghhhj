package com.example.aichat

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class ModelActivity : Activity() {
    private val bg = Color.rgb(8, 10, 13)
    private val surface = Color.rgb(17, 20, 24)
    private val surface2 = Color.rgb(25, 29, 35)
    private val border = Color.rgb(49, 58, 69)
    private val white = Color.rgb(242, 246, 250)
    private val muted = Color.rgb(151, 163, 177)

    private val green = Color.rgb(91, 239, 157)
    private val red = Color.rgb(255, 100, 126)
    private val blue = Color.rgb(89, 176, 255)

    private data class ModelDef(
        val id: String,
        val name: String,
        val description: String,
        val fileName: String,
        val url: String,
        val sizeText: String,
        val thinking: Boolean
    )

    private val models = listOf(
        ModelDef("smollm360", "SmolLM 360M Instruct", "Muito leve • chat geral", "SmolLM-360M-Instruct-Q4_K_M.gguf", "https://huggingface.co/second-state/SmolLM-360M-Instruct-GGUF/resolve/main/SmolLM-360M-Instruct-Q4_K_M.gguf?download=true", "≈271 MB", false),
        ModelDef("qwen25", "Qwen2.5 0.5B Instruct", "Leve • bom para português", "Qwen2.5-0.5B-Instruct-Q4_K_M.gguf", "https://huggingface.co/second-state/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf?download=true", "≈398 MB", false),
        ModelDef("qwen3", "Qwen3 0.6B", "Leve • suporte a thinking", "Qwen3-0.6B-Q4_K_M.gguf", "https://huggingface.co/second-state/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q4_K_M.gguf?download=true", "≈484 MB", true)
    )

    private lateinit var downloadedList: LinearLayout
    private lateinit var availableList: LinearLayout
    private var loadedPath: String? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadedPath = intent.getStringExtra("loaded_path")
        build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int = 12, strokeColor: Int = border) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), strokeColor)
    }

    private fun tv(t: String, size: Float, color: Int = white, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        includeFontPadding = true
    }

    private fun actionButton(text: String, fill: Int, strokeColor: Int, textColor: Int, icon: Int) = tv(text, 12f, textColor, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(12), 0, dp(12), 0)
        setCompoundDrawablesWithIntrinsicBounds(icon, 0, 0, 0)
        compoundDrawablePadding = dp(7)
        setBackground(bg(fill, 12, strokeColor))
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        scroll.addView(inner)

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = tv("‹", 34f).apply {
            gravity = Gravity.CENTER
            setBackground(bg(surface2))
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val title = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        title.addView(tv("Modelos", 21f, white, true))
        title.addView(tv("Baixe, importe e gerencie seus GGUF", 12f, muted))
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        inner.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val import = actionButton("Importar GGUF do armazenamento", surface2, Color.rgb(73, 93, 115), white, R.drawable.ic_upload).apply {
            setOnClickListener { if (!busy) pickImport() }
        }
        inner.addView(import, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(18) })

        val downloadedHeader = tv("  Baixados no aparelho", 15f, Color.rgb(226, 233, 241), true).apply {
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_storage, 0, 0, 0)
            compoundDrawablePadding = dp(6)
        }
        inner.addView(downloadedHeader, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        downloadedList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(downloadedList)

        val availableHeader = tv("  Modelos para baixar", 15f, Color.rgb(133, 201, 255), true).apply {
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_cloud, 0, 0, 0)
            compoundDrawablePadding = dp(6)
            setPadding(0, dp(14), 0, 0)
        }
        inner.addView(availableHeader, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        availableList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(availableList)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        downloadedList.removeAllViews()
        availableList.removeAllViews()

        var downloadedCount = 0
        models.forEach { model ->
            val file = File(filesDir, "models/${model.fileName}")
            if (file.exists()) {
                addModelCard(model, downloadedList)
                downloadedCount++
            } else {
                addModelCard(model, availableList)
            }
        }

        val dir = File(filesDir, "models")
        val known = models.map { it.fileName }.toSet()
        dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() == "gguf" && it.name !in known }
            ?.forEach {
                addLocalCard(it)
                downloadedCount++
            }

        if (downloadedCount == 0) {
            downloadedList.addView(tv("Nenhum modelo baixado ainda.", 12f, muted).apply {
                setPadding(dp(4), dp(5), dp(4), dp(14))
            })
        }
    }

    private fun addModelCard(m: ModelDef, target: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackground(bg(surface, 14, Color.rgb(43, 52, 63)))
        }
        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title.addView(tv(m.name, 16f, white, true))
        title.addView(tv("${m.description} • ${m.sizeText}${if (m.thinking) " • thinking" else ""}", 11f, muted))
        titleRow.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(titleRow)

        val file = File(filesDir, "models/${m.fileName}")
        if (file.exists()) {
            val loaded = loadedPath == file.absolutePath
            val info = tv(if (loaded) "Carregado" else "Baixado", 11f, if (loaded) green else muted).apply {
                setPadding(0, dp(8), 0, dp(5))
            }
            card.addView(info)
            val action = if (loaded) {
                actionButton("Descarregar", Color.rgb(55, 31, 39), Color.rgb(255, 78, 108), red, R.drawable.ic_upload)
            } else {
                actionButton("Carregar", Color.rgb(26, 55, 40), Color.rgb(77, 226, 147), green, R.drawable.ic_download)
            }
            action.setOnClickListener {
                val result = Intent().putExtra(if (loaded) "unload" else "model_path", file.absolutePath)
                setResult(RESULT_OK, result)
                finish()
            }
            card.addView(action, LinearLayout.LayoutParams(-1, dp(42)))
        } else {
            val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                visibility = View.GONE
            }
            card.addView(progress, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(10); bottomMargin = dp(8) })
            val action = actionButton("Baixar", Color.rgb(24, 48, 78), Color.rgb(67, 163, 255), blue, R.drawable.ic_download)
            action.setOnClickListener { download(m, progress, action) }
            card.addView(action, LinearLayout.LayoutParams(-1, dp(42)))
        }
        target.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun addLocalCard(file: File) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackground(bg(surface, 14, Color.rgb(43, 52, 63)))
        }
        card.addView(tv(file.name, 15f, white, true))
        card.addView(tv("GGUF local • ${file.length() / 1024 / 1024} MB", 11f, muted))
        val loaded = file.absolutePath == loadedPath
        val action = if (loaded) {
            actionButton("Descarregar", Color.rgb(55, 31, 39), Color.rgb(255, 78, 108), red, R.drawable.ic_upload)
        } else {
            actionButton("Carregar", Color.rgb(26, 55, 40), Color.rgb(77, 226, 147), green, R.drawable.ic_download)
        }
        action.setOnClickListener {
            setResult(RESULT_OK, Intent().putExtra(if (loaded) "unload" else "model_path", file.absolutePath))
            finish()
        }
        card.addView(action, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(9) })
        downloadedList.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun download(m: ModelDef, progress: ProgressBar, button: TextView) {
        if (busy) return
        busy = true
        button.isEnabled = false
        button.text = "Baixando…"
        progress.visibility = View.VISIBLE
        Thread {
            val target = File(filesDir, "models/${m.fileName}")
            target.parentFile?.mkdirs()
            val temp = File(target.absolutePath + ".part")
            try {
                val conn = (URL(m.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                }
                conn.connect()
                if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
                val total = conn.contentLengthLong
                var done = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            output.write(buffer, 0, n)
                            done += n
                            val pct = if (total > 0) (done * 100 / total).toInt() else -1
                            runOnUiThread {
                                if (pct >= 0) progress.progress = pct
                                button.text = if (total > 0) "${done / 1024 / 1024} / ${total / 1024 / 1024} MB" else "Baixando…"
                            }
                        }
                    }
                }
                if (!temp.renameTo(target)) throw IllegalStateException("Não consegui finalizar o arquivo.")
                runOnUiThread { busy = false; refresh() }
            } catch (e: Exception) {
                temp.delete()
                runOnUiThread {
                    busy = false
                    button.isEnabled = true
                    button.text = "Tentar novamente"
                    Toast.makeText(this, e.message ?: "Falha no download.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun pickImport() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/octet-stream"
            addCategory(Intent.CATEGORY_OPENABLE)
        }, 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            try {
                val name = queryName(uri) ?: "model.gguf"
                require(name.lowercase().endsWith(".gguf")) { "Selecione um arquivo .gguf." }
                val dst = File(filesDir, "models/$name")
                dst.parentFile?.mkdirs()
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Não consegui abrir o arquivo." }
                    FileOutputStream(dst).use { output -> input.copyTo(output, 1024 * 1024) }
                }
                runOnUiThread {
                    Toast.makeText(this, "Modelo copiado para a pasta do app.", Toast.LENGTH_SHORT).show()
                    refresh()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, e.message ?: "Falha ao importar.", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }
}
