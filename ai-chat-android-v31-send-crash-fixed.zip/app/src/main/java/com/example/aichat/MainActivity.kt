package com.example.aichat

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.text.TextWatcher
import android.view.Window
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : Activity() {
    private lateinit var engine: LlamaEngine

    private lateinit var root: FrameLayout
    private lateinit var chatContainer: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var attachButton: ImageButton
    private lateinit var importButton: TextView
    private lateinit var modelsButton: TextView
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var attachmentChip: TextView
    private lateinit var drawer: LinearLayout
    private lateinit var chatList: LinearLayout

    private var modelFile: File? = null
    private var generating = false
    private var currentAssistantContent: LinearLayout? = null
    private var currentThinkingBox: LinearLayout? = null
    private var currentThinkingHeader: TextView? = null
    private var currentThinkingBody: TextView? = null

    private data class ChatSession(
        var title: String,
        val history: MutableList<Pair<String, String>> = mutableListOf()
    )

    /**
     * Last-line-of-defense stream router. Some GGUF templates/parsers can still
     * deliver literal reasoning tags through onToken (for example <think>...</think>)
     * instead of separate reasoning callbacks. Keep the UI independent from that
     * implementation detail: anything between known reasoning tags goes to the
     * separate Thinking panel, and the tags themselves never reach the answer bubble.
     */
    private class OutputRouter(
        private val onThinkingStart: () -> Unit,
        private val onThinking: (String) -> Unit,
        private val onAnswer: (String) -> Unit
    ) {
        private enum class Mode { UNKNOWN, THINKING, ANSWER }
        private var mode = Mode.UNKNOWN
        private var pending = ""

        private val starts = listOf("<think>", "<thinking>", "<reasoning>", "<analysis>")
        private val ends = listOf("</think>", "</thinking>", "</reasoning>", "</analysis>")

        fun markNativeThinkingStart() {
            // The native layer can tell us that the rendered prompt already
            // starts inside a reasoning block. Keep using the same raw-tag
            // router for subsequent token pieces so </think> is still handled.
            mode = Mode.THINKING
            pending = ""
            onThinkingStart()
        }

        fun token(text: String) {
            if (text.isEmpty()) return
            // Always route the raw stream through the tag parser. This is the
            // deliberately simple last line of defense: everything between a
            // reasoning start/end tag belongs to the separate Thinking panel.
            pending += text
            process(false)
        }

        fun finish() {
            process(true)
            if (pending.isNotEmpty()) {
                if (mode == Mode.THINKING) onThinking(pending) else onAnswer(pending)
                pending = ""
            }
        }

        private fun process(final: Boolean) {
            while (pending.isNotEmpty()) {
                val lower = pending.lowercase()

                if (mode == Mode.UNKNOWN || mode == Mode.ANSWER) {
                    val start = starts.map { it.lowercase() }.mapIndexedNotNull { i, tag ->
                        val idx = lower.indexOf(tag)
                        if (idx >= 0) idx to i else null
                    }.minByOrNull { it.first }

                    if (start != null) {
                        val idx = start.first
                        if (idx > 0) onAnswer(pending.substring(0, idx))
                        pending = pending.substring(idx + starts[start.second].length)
                        mode = Mode.THINKING
                        onThinkingStart()
                        continue
                    }

                    // Keep enough trailing characters to catch a tag split across
                    // two llama.cpp token pieces.
                    if (!final) {
                        val keep = (starts.maxOf { it.length } - 1).coerceAtMost(pending.length)
                        val emitLen = pending.length - keep
                        if (emitLen > 0) {
                            onAnswer(pending.substring(0, emitLen))
                            pending = pending.substring(emitLen)
                        }
                    } else {
                        onAnswer(pending)
                        pending = ""
                    }
                    return
                }

                // If native told us we started inside thinking and the model still
                // emits a literal opening tag, strip that duplicate tag instead of
                // showing it in the Thinking text.
                val duplicateStart = starts.map { it.lowercase() }
                    .mapIndexedNotNull { i, tag ->
                        val idx = lower.indexOf(tag)
                        if (idx >= 0) idx to i else null
                    }.minByOrNull { it.first }

                if (duplicateStart != null && duplicateStart.first == 0) {
                    pending = pending.substring(starts[duplicateStart.second].length)
                    continue
                }

                val end = ends.map { it.lowercase() }.mapIndexedNotNull { i, tag ->
                    val idx = lower.indexOf(tag)
                    if (idx >= 0) idx to i else null
                }.minByOrNull { it.first }

                if (end != null) {
                    if (end.first > 0) onThinking(pending.substring(0, end.first))
                    pending = pending.substring(end.first + ends[end.second].length)
                    mode = Mode.ANSWER
                    continue
                }

                if (!final) {
                    val keep = (ends.maxOf { it.length } - 1).coerceAtMost(pending.length)
                    val emitLen = pending.length - keep
                    if (emitLen > 0) {
                        onThinking(pending.substring(0, emitLen))
                        pending = pending.substring(emitLen)
                    }
                } else {
                    onThinking(pending)
                    pending = ""
                }
                return
            }
        }
    }

    private val sessions = mutableListOf<ChatSession>()
    private var currentSessionIndex = 0

    private var attachmentName: String? = null
    private var attachmentContent: String? = null

    private val systemPrompt =
        "Você é um assistente útil, direto e natural. Responda no idioma usado pelo usuário. " +
        "Se a mensagem for curta, responda de forma curta e natural. " +
        "Não prolongue vogais ou pontuação, não repita letras sem motivo e não use sequências como Oiiii ou ????. " +
        "Não invente informações quando não souber."

    private val bg = Color.rgb(10, 10, 10)
    private val surface = Color.rgb(20, 20, 20)
    private val surface2 = Color.rgb(28, 28, 28)
    private val border = Color.rgb(48, 48, 48)
    private val white = Color.rgb(245, 245, 245)
    private val muted = Color.rgb(150, 150, 150)
    private val subtle = Color.rgb(105, 105, 105)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }

        engine = LlamaEngine(this)
        sessions.add(ChatSession("Nova conversa"))
        buildUi()
        renderConversation()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 14, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(1), border)
        }

    private fun stroked(color: Int, radius: Int, strokeColor: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), strokeColor)
        }

    private fun textView(
        value: String,
        size: Float,
        color: Int = white,
        bold: Boolean = false
    ) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        includeFontPadding = true
    }

    private inner class ShimmerEditText(context: Context) : androidx.appcompat.widget.AppCompatEditText(context) {
        private var offset = -260f
        private var animator: ValueAnimator? = null

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            animator = ValueAnimator.ofFloat(-260f, 520f).apply {
                duration = 1850L
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener {
                    offset = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }

        override fun onDetachedFromWindow() {
            animator?.cancel()
            animator = null
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: android.graphics.Canvas) {
            if (text.isNullOrEmpty()) {
                paint.shader = LinearGradient(
                    offset, 0f, offset + 115f, 0f,
                    intArrayOf(subtle, Color.rgb(205, 211, 218), subtle),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
            } else {
                paint.shader = null
            }
            super.onDraw(canvas)
            paint.shader = null
        }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(bg)
        }

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val bottom = maxOf(bars.bottom, ime.bottom)
            view.setPadding(
                dp(14),
                bars.top + dp(8),
                dp(14),
                bottom + dp(10)
            )
            insets
        }
        ViewCompat.requestApplyInsets(root)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        // App bar
        val appBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }

        val menuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_menu)
            contentDescription = "Abrir conversas"
            scaleType = ImageView.ScaleType.CENTER
            setBackground(rounded(surface2, 12, 1))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { toggleDrawer() }
        }
        appBar.addView(menuButton, LinearLayout.LayoutParams(dp(48), dp(46)))

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titleBox.addView(textView("AI Chat", 20f, Color.rgb(235, 247, 255), true))
        titleBox.addView(textView("llama.cpp  •  local", 12f, Color.rgb(93, 207, 255)))
        appBar.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))

        val modelButton = textView("  Modelos", 12f, white, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(13), 0)
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_model, 0, 0, 0)
            setBackground(rounded(surface2, 12, 1))
            setOnClickListener { openModels() }
        }
        appBar.addView(modelButton, LinearLayout.LayoutParams(-2, dp(40)))

        content.addView(appBar)

        // Status / metrics
        val statusRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackground(stroked(Color.rgb(16, 20, 25), 12, Color.rgb(43, 93, 112)))
        }

        status = textView("○  Nenhum modelo carregado", 12f, muted)
        statusRow.addView(status, LinearLayout.LayoutParams(0, -2, 1f))

        stats = textView("0 tok", 11f, Color.rgb(132, 182, 208)).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        statusRow.addView(stats)

        content.addView(
            statusRow,
            LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) }
        )

        // Chat area
        chatContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(10), dp(2), dp(14))
        }

        chatScroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(
                chatContainer,
                ViewGroup.LayoutParams(-1, -2)
            )
        }
        content.addView(
            chatScroll,
            LinearLayout.LayoutParams(-1, 0, 1f).apply {
                bottomMargin = dp(8)
            }
        )

        // Composer — compact, with a minimal attachment button and send circle.
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(5), dp(6), dp(5))
            setBackground(stroked(Color.rgb(19, 22, 26), 18, Color.rgb(48, 58, 68)))
        }

        attachButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_add)
            contentDescription = "Adicionar arquivo"
            scaleType = ImageView.ScaleType.CENTER
            setPadding(dp(9), dp(9), dp(9), dp(9))
            setBackground(rounded(surface2, 14, 1))
            setOnClickListener { pickAttachment() }
        }
        composer.addView(attachButton, LinearLayout.LayoutParams(dp(40), dp(40)).apply {
            rightMargin = dp(5)
        })

        input = ShimmerEditText(this).apply {
            hint = "Ask assistant..."
            textSize = 16f
            setTextColor(white)
            setHintTextColor(Color.TRANSPARENT)
            setSingleLine(false)
            minLines = 1
            maxLines = 4
            gravity = Gravity.CENTER_VERTICAL
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(8), dp(3), dp(8), dp(3))
            setBackgroundColor(Color.TRANSPARENT)
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else false
        }

        composer.addView(input, LinearLayout.LayoutParams(0, dp(40), 1f))

        sendButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_send)
            contentDescription = "Enviar mensagem"
            scaleType = ImageView.ScaleType.CENTER
            setPadding(dp(9), dp(9), dp(9), dp(9))
            setBackground(rounded(Color.rgb(246, 248, 250), 20, 0))
            setOnClickListener { sendMessage() }
        }
        composer.addView(sendButton, LinearLayout.LayoutParams(dp(40), dp(40)).apply {
            leftMargin = dp(5)
        })

        content.addView(composer, LinearLayout.LayoutParams(-1, dp(50)))

        // Side menu
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(18), dp(14), dp(14))
            setBackground(stroked(Color.rgb(12, 15, 19), 0, Color.rgb(36, 74, 91)))
            elevation = dp(12).toFloat()
        }

        val drawerHeader = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        drawerHeader.addView(textView("Conversas", 20f, white, true),
            LinearLayout.LayoutParams(0, -2, 1f))

        val newChat = textView("+", 26f, white).apply {
            gravity = Gravity.CENTER
            setBackground(rounded(surface2, 12, 1))
            setOnClickListener {
                newConversation()
                closeDrawer()
            }
        }
        drawerHeader.addView(newChat, LinearLayout.LayoutParams(dp(44), dp(44)))
        drawer.addView(drawerHeader)

        modelsButton = textView("◈  Modelos", 13f, white).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            setBackground(rounded(surface2, 12, 1))
            setOnClickListener { if (!generating) openModels() }
        }
        drawer.addView(
            modelsButton,
            LinearLayout.LayoutParams(-1, dp(44)).apply {
                topMargin = dp(14)
                bottomMargin = dp(8)
            }
        )

        importButton = textView("＋  Importar modelo GGUF", 13f, white).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            setBackground(rounded(surface2, 12, 1))
            setOnClickListener { pickModel() }
        }
        drawer.addView(
            importButton,
            LinearLayout.LayoutParams(-1, dp(44)).apply {
                topMargin = dp(14)
                bottomMargin = dp(8)
            }
        )

        val settingsButton = textView("⚙  Configurações da engine", 13f, white).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            setBackground(rounded(surface2, 12, 1))
            setOnClickListener {
                if (!generating) {
                    startActivityForResult(Intent(this@MainActivity, SettingsActivity::class.java), 200)
                }
            }
        }
        drawer.addView(
            settingsButton,
            LinearLayout.LayoutParams(-1, dp(44)).apply {
                bottomMargin = dp(14)
            }
        )

        val divider = View(this).apply { setBackgroundColor(border) }
        drawer.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))

        chatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val drawerScroll = ScrollView(this).apply {
            addView(chatList, ViewGroup.LayoutParams(-1, -2))
        }
        drawer.addView(drawerScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val drawerWidth = minOf(dp(320), (resources.displayMetrics.widthPixels * 0.82f).toInt())
        root.addView(
            drawer,
            FrameLayout.LayoutParams(drawerWidth, -1).apply {
                gravity = Gravity.START
            }
        )

        drawer.visibility = View.GONE
        setContentView(root)
    }

    private fun openModels() {
        if (generating) return
        closeDrawer()
        startActivityForResult(
            Intent(this, ModelActivity::class.java)
                .putExtra("loaded_path", modelFile?.absolutePath),
            300
        )
    }

    private fun toggleDrawer() {
        drawer.visibility = if (drawer.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (drawer.visibility == View.VISIBLE) refreshChatList()
    }

    private fun closeDrawer() {
        drawer.visibility = View.GONE
    }

    private fun refreshChatList() {
        chatList.removeAllViews()

        sessions.forEachIndexed { index, session ->
            val row = textView(
                if (index == currentSessionIndex) "●  ${session.title}" else "   ${session.title}",
                13f,
                if (index == currentSessionIndex) white else muted,
                index == currentSessionIndex
            ).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(8), 0)
                setBackground(rounded(if (index == currentSessionIndex) surface2 else Color.TRANSPARENT, 10))
                setOnClickListener {
                    if (!generating) {
                        currentSessionIndex = index
                        clearAttachment()
                        renderConversation()
                        closeDrawer()
                    }
                }
            }
            chatList.addView(
                row,
                LinearLayout.LayoutParams(-1, dp(46)).apply {
                    bottomMargin = dp(3)
                }
            )
        }
    }

    private fun newConversation() {
        if (generating) return
        sessions.add(ChatSession("Nova conversa"))
        currentSessionIndex = sessions.lastIndex
        clearAttachment()
        renderConversation()
    }

    private fun currentSession(): ChatSession = sessions[currentSessionIndex]

    private fun renderConversation() {
        chatContainer.removeAllViews()
        val history = currentSession().history

        if (history.isEmpty()) {
            val welcome = textView(
                "Conversa local\n\nImporte um GGUF e mande uma mensagem.",
                16f,
                muted
            ).apply {
                setPadding(dp(18), dp(18), dp(18), dp(18))
                setBackground(rounded(surface, 16, 1))
            }
            chatContainer.addView(welcome, LinearLayout.LayoutParams(-1, -2))
        } else {
            history.forEach { (role, message) ->
                if (role == "user") addBubble("Você", message, true) else addAssistantHistory(message)
            }
        }
        scrollToBottom()
        refreshChatList()
    }

    private fun addBubble(label: String, message: String, user: Boolean): TextView {
        val bubble = textView("", 15f, white)
        if (message.isNotEmpty()) MarkdownRenderer.apply(bubble, message)
        bubble.setLineSpacing(0f, 1.12f)
        bubble.setPadding(dp(15), dp(11), dp(15), dp(11))
        bubble.setBackground(
            if (user) stroked(Color.rgb(24, 35, 43), 16, Color.rgb(46, 126, 157))
            else stroked(surface, 16, Color.rgb(48, 57, 68))
        )

        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(if (user) dp(42) else dp(4), dp(3), if (user) dp(4) else dp(42), dp(5))
        }

        val labelView = textView(label.uppercase(Locale.getDefault()), 10f, subtle, true)
        labelView.setPadding(dp(3), 0, dp(3), dp(4))
        wrap.addView(labelView)
        wrap.addView(bubble)

        chatContainer.addView(wrap, LinearLayout.LayoutParams(-1, -2))
        return bubble
    }

    private fun addAssistantHistory(message: String) {
        val content = addAssistantBubble()
        MarkdownRenderer.renderInto(content, message)
    }

    private fun addAssistantBubble(): LinearLayout {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(3), dp(42), dp(5))
        }

        val labelView = textView("IA", 10f, subtle, true)
        labelView.setPadding(dp(3), 0, dp(3), dp(4))
        wrap.addView(labelView)

        // Thinking is deliberately OUTSIDE the answer bubble. It can expand/collapse
        // without changing the visual identity of the final response.
        val thinkingBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackground(stroked(Color.rgb(31, 34, 39), 13, Color.rgb(79, 86, 96)))
            visibility = View.GONE
        }
        val thinkingHeader = textView("  Thinking", 12f, Color.rgb(218, 224, 231), true).apply {
            setPadding(0, 0, 0, dp(3))
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_brain, 0, 0, 0)
            compoundDrawablePadding = dp(6)
        }
        val thinkingBody = textView("", 13f, muted).apply {
            setLineSpacing(0f, 1.1f)
            visibility = View.GONE
        }
        thinkingHeader.setOnClickListener {
            val expanded = thinkingBody.visibility != View.VISIBLE
            thinkingBody.visibility = if (expanded) View.VISIBLE else View.GONE
            thinkingHeader.text = if (expanded) "⌃  Pensamento" else "⌄  Pensamento"
        }
        thinkingBox.addView(thinkingHeader)
        thinkingBox.addView(thinkingBody)
        wrap.addView(thinkingBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val answerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(12), dp(15), dp(12))
            setBackground(stroked(Color.rgb(18, 21, 26), 16, Color.rgb(48, 57, 68)))
        }
        wrap.addView(answerCard, LinearLayout.LayoutParams(-1, -2))

        chatContainer.addView(wrap, LinearLayout.LayoutParams(-1, -2))
        currentThinkingBox = thinkingBox
        currentThinkingHeader = thinkingHeader
        currentThinkingBody = thinkingBody
        currentAssistantContent = answerCard
        return answerCard
    }

    private fun sendMessage() {
        val typed = input.text.toString().trim()
        if (typed.isEmpty() || generating) return

        if (modelFile == null) {
            status.text = "○  Importe um modelo GGUF primeiro"
            return
        }

        val prompt = if (attachmentContent != null) {
            "$typed\n\n[Arquivo: ${attachmentName ?: "anexo"}]\n${attachmentContent}"
        } else typed

        input.setText("")
        generating = true
        setControlsEnabled(false)

        val session = currentSession()
        if (session.history.isEmpty()) {
            session.title = typed.replace(Regex("\\s+"), " ").take(30).ifBlank { "Nova conversa" }
        }

        session.history.add("user" to prompt)

        // Remove the welcome card and add the new user message.
        if (session.history.size == 1) chatContainer.removeAllViews()
        addBubble("Você", typed, true)
        if (attachmentName != null) {
            val fileLine = textView("📎 ${attachmentName}", 11f, muted).apply {
                setPadding(dp(48), 0, dp(8), dp(5))
            }
            chatContainer.addView(fileLine, 0)
        }

        addAssistantBubble()
        currentThinkingBox?.visibility = View.GONE
        currentThinkingHeader?.visibility = View.GONE
        currentThinkingBody?.visibility = View.GONE
        attachmentName = null
        attachmentContent = null
        attachmentChip.visibility = View.GONE

        val messages = mutableListOf<Pair<String, String>>()
        messages.add("system" to systemPrompt)
        messages.addAll(session.history)

        val answer = StringBuilder()
        val thinking = StringBuilder()
        var lastRenderAt = 0L
        lateinit var router: OutputRouter
        router = OutputRouter(
            onThinkingStart = {
                currentThinkingBox?.visibility = View.VISIBLE
                currentThinkingHeader?.visibility = View.VISIBLE
                currentThinkingBody?.visibility = View.VISIBLE
                currentThinkingHeader?.text = "  Thinking"
                currentThinkingBox?.setBackground(stroked(Color.rgb(74, 78, 84), 13, Color.rgb(245, 247, 250)))
                if (thinking.isEmpty()) currentThinkingBody?.text = ""
                scrollToBottom()
            },
            onThinking = { token ->
                thinking.append(token)
                currentThinkingBox?.visibility = View.VISIBLE
                currentThinkingHeader?.visibility = View.VISIBLE
                currentThinkingBody?.visibility = View.VISIBLE
                currentThinkingHeader?.text = "  Thinking"
                currentThinkingBox?.setBackground(stroked(Color.rgb(74, 78, 84), 13, Color.rgb(245, 247, 250)))
                currentThinkingBody?.let { it.text = thinking.toString() }
                scrollToBottom()
            },
            onAnswer = { token ->
                answer.append(token)
                val now = System.currentTimeMillis()
                if (now - lastRenderAt >= 60L || token.contains("\n")) {
                    lastRenderAt = now
                    currentAssistantContent?.let { MarkdownRenderer.renderInto(it, answer.toString()) }
                    scrollToBottom()
                }
            }
        )

        status.text = "●  Gerando..."
        stats.text = "0 tok"

        Thread {
            try {
                engine.generateStreaming(
                    messages,
                    object : LlamaEngine.StreamCallback {
                        override fun onToken(token: String) {
                            runOnUiThread { router.token(token) }
                        }

                        override fun onThinkingStart() {
                            runOnUiThread { router.markNativeThinkingStart() }
                        }

                        override fun onStats(
                            generatedTokens: Int,
                            promptTokens: Int,
                            tokensPerSecond: Double
                        ) {
                            runOnUiThread {
                                stats.text = String.format(
                                    Locale.US,
                                    "%d tok  •  %.1f tok/s",
                                    generatedTokens + promptTokens,
                                    tokensPerSecond
                                )
                            }
                        }

                        override fun onComplete() {
                            runOnUiThread {
                                router.finish()
                                session.history.add("assistant" to answer.toString())
                                currentAssistantContent?.let { MarkdownRenderer.renderInto(it, answer.toString()) }
                                if (thinking.isNotEmpty()) {
                                    currentThinkingHeader?.visibility = View.VISIBLE
                                    // Finished thinking starts collapsed, but the header stays
                                    // visible so the user can tap it to expand again.
                                    currentThinkingBody?.visibility = View.GONE
                                    currentThinkingHeader?.text = "  Thinking"
                                    currentThinkingBox?.setBackground(stroked(Color.rgb(31, 34, 39), 13, Color.rgb(79, 86, 96)))
                                    currentThinkingBody?.let { it.text = thinking.toString() }
                                }
                                generating = false
                                currentAssistantContent = null
                                currentThinkingHeader = null
                                currentThinkingBody = null
                                setControlsEnabled(true)
                                status.text = "✓  Pronto"
                                refreshChatList()
                                scrollToBottom()
                            }
                        }

                        override fun onError(message: String) {
                            if (session.history.lastOrNull()?.first == "user") {
                                session.history.removeAt(session.history.lastIndex)
                            }
                            runOnUiThread {
                                currentAssistantContent?.removeAllViews(); currentAssistantContent?.addView(textView("Erro: $message", 15f, white))
                                currentAssistantContent = null
                                generating = false
                                setControlsEnabled(true)
                                status.text = "○  Erro na geração"
                                scrollToBottom()
                            }
                        }
                    },
                    EngineSettings.from(this@MainActivity)
                )
            } catch (e: Exception) {
                if (session.history.lastOrNull()?.first == "user") {
                    session.history.removeAt(session.history.lastIndex)
                }
                runOnUiThread {
                    currentAssistantContent?.removeAllViews(); currentAssistantContent?.addView(textView("Erro: ${e.message ?: "desconhecido"}", 15f, white))
                    currentAssistantContent = null
                    generating = false
                    setControlsEnabled(true)
                    status.text = "○  Erro na geração"
                }
            }
        }.start()

        refreshChatList()
        scrollToBottom()
    }

    private fun pickModel() {
        if (generating) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/octet-stream"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 100)
    }

    private fun pickAttachment() {
        if (generating) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 101)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 300 && resultCode == RESULT_OK) {
            if (data?.getBooleanExtra("unload", false) == true) {
                if (!generating) {
                    engine.unload()
                    modelFile = null
                    status.text = "○  Modelo descarregado"
                    stats.text = "0 tok"
                }
                return
            }
            data?.getStringExtra("model_path")?.let { path ->
                if (!generating) loadModelFile(File(path))
            }
            return
        }

        if (requestCode == 200 && resultCode == RESULT_OK && modelFile != null) {
            reloadCurrentModel()
            return
        }

        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        if (requestCode == 100) loadModel(uri)
        else if (requestCode == 101) loadAttachment(uri)
    }

    private fun reloadCurrentModel() {
        val file = modelFile ?: return
        status.text = "◌  Recarregando modelo com novas configurações..."
        setControlsEnabled(false)
        closeDrawer()

        Thread {
            try {
                engine.load(file.absolutePath, EngineSettings.from(this))
                runOnUiThread {
                    status.text = "✓  Configurações aplicadas"
                    stats.text = "0 tok"
                    setControlsEnabled(true)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "○  Falha ao aplicar configurações"
                    setControlsEnabled(true)
                    Toast.makeText(
                        this,
                        e.message ?: "Não foi possível recarregar o modelo.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun loadModel(uri: Uri) {
        Thread {
            try {
                val name = queryName(uri) ?: "model.gguf"
                val dst = File(filesDir, "models/$name")
                dst.parentFile?.mkdirs()

                contentResolver.openInputStream(uri).use { inputStream ->
                    requireNotNull(inputStream) { "Não consegui abrir o arquivo." }
                    FileOutputStream(dst).use { output ->
                        inputStream.copyTo(output, 1024 * 1024)
                    }
                }
                runOnUiThread { loadModelFile(dst) }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "○  Falha ao importar modelo"
                    setControlsEnabled(true)
                    Toast.makeText(this, e.message ?: "Erro desconhecido", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun loadModelFile(file: File) {
        if (generating) return
        status.text = "◌  Carregando ${file.name}..."
        setControlsEnabled(false)

        Thread {
            try {
                engine.load(file.absolutePath)
                runOnUiThread {
                    modelFile = file
                    sessions.clear()
                    sessions.add(ChatSession("Nova conversa"))
                    currentSessionIndex = 0
                    status.text = "✓  ${file.name}"
                    stats.text = "0 tok"
                    setControlsEnabled(true)
                    renderConversation()
                    closeDrawer()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "○  Falha ao carregar modelo"
                    setControlsEnabled(true)
                    Toast.makeText(this, e.message ?: "Não foi possível carregar o modelo.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun loadAttachment(uri: Uri) {
        Thread {
            try {
                val name = queryName(uri) ?: "arquivo"
                val bytes = contentResolver.openInputStream(uri).use {
                    requireNotNull(it) { "Não consegui abrir o arquivo." }.readBytes()
                }

                if (bytes.size > 256 * 1024) {
                    throw IllegalArgumentException("Arquivo muito grande. O limite do anexo é 256 KB.")
                }

                val content = bytes.toString(Charsets.UTF_8).replace("\u0000", "")
                if (content.isBlank()) {
                    throw IllegalArgumentException("Esse arquivo não parece ser texto.")
                }

                runOnUiThread {
                    attachmentName = name
                    attachmentContent = content
                    attachmentChip.text = "  $name  ×"
                    attachmentChip.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this,
                        e.message ?: "Não foi possível ler o arquivo.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun clearAttachment() {
        attachmentName = null
        attachmentContent = null
        if (::attachmentChip.isInitialized) attachmentChip.visibility = View.GONE
    }

    private fun setControlsEnabled(enabled: Boolean) {
        input.isEnabled = enabled
        attachButton.isEnabled = enabled
        sendButton.isEnabled = enabled
        importButton.isEnabled = enabled
        modelsButton.isEnabled = enabled
    }

    private fun scrollToBottom() {
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    override fun onBackPressed() {
        if (::drawer.isInitialized && drawer.visibility == View.VISIBLE) {
            closeDrawer()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Native resources are released by LlamaEngine.finalize().
    }
}
