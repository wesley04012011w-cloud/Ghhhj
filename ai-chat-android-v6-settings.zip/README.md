# AI Chat Android — v0.4

Chat local Android com `llama.cpp` + GGUF.

## O que mudou nesta versão

- UI dark sem exagero de cores.
- Conteúdo respeita status bar, navigation bar e IME/teclado via WindowInsets.
- Composer continua visível quando o teclado Samsung/Android abre.
- Menu lateral com conversas e acesso a **Configurações da engine**.
- Configurações persistentes:
  - contexto;
  - batch;
  - threads CPU;
  - MMAP;
  - Flash Attention;
  - tipo de KV cache (F16/Q8_0/Q4_0);
  - temperatura;
  - Top-K;
  - Top-P;
  - Min-P;
  - repetição;
  - repeat-last-N;
  - máximo de tokens;
  - seed.
- Alterações de engine são aplicadas ao recarregar o modelo.
- Streaming e chat template do GGUF continuam ativos.

As opções de contexto, KV cache e Flash Attention correspondem aos parâmetros atuais expostos pelo `llama.cpp`; tipos KV quantizados exigem Flash Attention. A documentação upstream também expõe batch, threads, temperatura, Top-K, Top-P, Min-P e penalidade de repetição como parâmetros de execução. 
