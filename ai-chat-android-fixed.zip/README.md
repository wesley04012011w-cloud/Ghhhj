# AI Chat Android — llama.cpp

Projeto Android mínimo para inferência local de modelos GGUF.

## Layout para GitHub pelo celular

Você não precisa mover os arquivos do projeto individualmente.

No seu repositório GitHub, coloque somente:

```text
seu-repo/
├── ai-chat-android.zip
└── .github/
    └── workflows/
        └── build-from-zip.yml
```

O workflow extrai o ZIP, instala Java/Android SDK/NDK/CMake, baixa uma versão fixada do llama.cpp e compila o APK.

## Importação do modelo

O app usa o seletor de documentos do Android. O usuário escolhe um arquivo `.gguf`, e o app copia o modelo para o armazenamento privado do aplicativo antes de carregá-lo.

## Arquitetura

- Kotlin para UI/importação.
- JNI + C++ para a engine.
- llama.cpp para inferência.
- `arm64-v8a`.
- CMake + Android NDK.

A configuração segue as recomendações atuais do llama.cpp para Android: `GGML_NATIVE=OFF`, `GGML_OPENMP=OFF`, `GGML_LLAMAFILE=OFF`, com KleidiAI habilitado para `arm64-v8a`.

## Build

O projeto não precisa conter o código do llama.cpp. `scripts/fetch-llama.sh` baixa a versão fixada durante o build.

Para mudar a versão sem editar o projeto, defina `LLAMA_REF` no workflow.

## Limitação atual

A primeira versão retorna a resposta depois da geração. O próximo upgrade recomendado é streaming de tokens via JNI/Kotlin Flow e controle de contexto/threads/batch pela UI.
