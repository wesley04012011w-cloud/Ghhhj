package com.example.aichat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var engine: LlamaEngine
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private var modelFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = LlamaEngine(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }

        val import = Button(this).apply {
            text = "Importar modelo GGUF"
            setOnClickListener { pickModel() }
        }

        status = TextView(this).apply {
            text = "Nenhum modelo carregado"
            setPadding(0, 10, 0, 10)
        }

        chat = TextView(this).apply {
            text = "Escolha um modelo GGUF para começar."
            textSize = 16f
            setPadding(0, 10, 0, 10)
        }

        input = EditText(this).apply {
            hint = "Digite sua mensagem..."
            minLines = 2
            gravity = Gravity.TOP
        }

        val send = Button(this).apply {
            text = "Enviar"
            setOnClickListener { sendMessage() }
        }

        root.addView(import)
        root.addView(status)
        root.addView(chat, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input)
        root.addView(send)
        setContentView(root)
    }

    private fun pickModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/octet-stream"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        Thread {
            try {
                val name = queryName(uri) ?: "model.gguf"
                val dst = File(filesDir, "models/$name")
                dst.parentFile?.mkdirs()

                contentResolver.openInputStream(uri).use { input ->
                    FileOutputStream(dst).use { output ->
                        input!!.copyTo(output, 1024 * 1024)
                    }
                }

                runOnUiThread {
                    status.text = "Carregando: $name"
                    chat.text = ""
                }

                engine.load(dst.absolutePath)

                runOnUiThread {
                    modelFile = dst
                    status.text = "Modelo carregado: $name"
                    chat.text = "Pronto. Pode conversar."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Erro: ${e.message}" }
            }
        }.start()
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        if (modelFile == null) {
            status.text = "Importe um modelo primeiro."
            return
        }

        input.setText("")
        chat.append("\n\nVocê: $prompt\nIA: ")

        Thread {
            try {
                val answer = engine.generate(prompt)
                runOnUiThread { chat.append(answer) }
            } catch (e: Exception) {
                runOnUiThread { chat.append("\n[erro: ${e.message}]") }
            }
        }.start()
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        return uri.lastPathSegment?.substringAfterLast('/')
    }
}
