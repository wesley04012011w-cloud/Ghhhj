package com.example.aichat

import android.content.Context

class LlamaEngine(context: Context) {
    companion object {
        init { System.loadLibrary("aichat") }
    }

    private val handle: Long = nativeCreate()

    fun load(path: String) {
        check(nativeLoad(handle, path)) { "Não foi possível carregar o modelo." }
    }

    fun generate(prompt: String): String = nativeGenerate(handle, prompt)

    protected fun finalize() {
        nativeDestroy(handle)
    }

    private external fun nativeCreate(): Long
    private external fun nativeLoad(handle: Long, path: String): Boolean
    private external fun nativeGenerate(handle: Long, prompt: String): String
    private external fun nativeDestroy(handle: Long)
}
