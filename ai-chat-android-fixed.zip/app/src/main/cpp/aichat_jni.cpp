#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include "llama.h"

struct Engine {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    std::mutex mutex;
};

static std::string jstring_to_string(JNIEnv *env, jstring s) {
    const char *p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    env->ReleaseStringUTFChars(s, p);
    return out;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_aichat_LlamaEngine_nativeCreate(JNIEnv*, jobject) {
    llama_backend_init();
    auto *e = new Engine();
    return reinterpret_cast<jlong>(e);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_aichat_LlamaEngine_nativeLoad(JNIEnv *env, jobject,
                                                jlong handle, jstring path) {
    auto *e = reinterpret_cast<Engine*>(handle);
    std::lock_guard<std::mutex> lock(e->mutex);

    if (e->ctx) {
        llama_free(e->ctx);
        e->ctx = nullptr;
    }
    if (e->model) {
        llama_model_free(e->model);
        e->model = nullptr;
    }

    llama_model_params mp = llama_model_default_params();
    std::string p = jstring_to_string(env, path);
    e->model = llama_model_load_from_file(p.c_str(), mp);
    if (!e->model) return JNI_FALSE;

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 2048;
    cp.n_batch = 512;
    cp.n_threads = 0;
    cp.n_threads_batch = 0;

    e->ctx = llama_init_from_model(e->model, cp);
    if (!e->ctx) {
        llama_model_free(e->model);
        e->model = nullptr;
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_aichat_LlamaEngine_nativeGenerate(JNIEnv *env, jobject,
                                                    jlong handle, jstring prompt) {
    auto *e = reinterpret_cast<Engine*>(handle);
    std::lock_guard<std::mutex> lock(e->mutex);

    if (!e->model || !e->ctx)
        return env->NewStringUTF("Modelo não carregado.");

    std::string text = jstring_to_string(env, prompt);

    const llama_vocab *vocab = llama_model_get_vocab(e->model);
    std::vector<llama_token> tokens(text.size() + 64);
    int n = llama_tokenize(vocab, text.c_str(), text.size(),
                           tokens.data(), tokens.size(), true, true);
    if (n < 0) {
        tokens.resize(-n);
        n = llama_tokenize(vocab, text.c_str(), text.size(),
                           tokens.data(), tokens.size(), true, true);
    }
    if (n <= 0) return env->NewStringUTF("Não consegui tokenizar o prompt.");
    tokens.resize(n);

    llama_memory_clear(llama_get_memory(e->ctx), true);

    llama_batch batch = llama_batch_init(512, 0, 1);
    for (int i = 0; i < n; ++i) {
        batch.token[i] = tokens[i];
        batch.pos[i] = i;
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == n - 1);
    }
    batch.n_tokens = n;

    if (llama_decode(e->ctx, batch) != 0) {
        llama_batch_free(batch);
        return env->NewStringUTF("Falha no decode inicial.");
    }

    std::string output;
    const int max_new_tokens = 256;
    int cur_pos = n;

    llama_sampler_chain_params sp = llama_sampler_chain_default_params();
    llama_sampler *sampler = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(1234));

    for (int i = 0; i < max_new_tokens; ++i) {
        llama_token token = llama_sampler_sample(sampler, e->ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;

        char buf[256];
        int len = llama_token_to_piece(vocab, token, buf, sizeof(buf), 0, true);
        if (len > 0) output.append(buf, len);

        batch.n_tokens = 1;
        batch.token[0] = token;
        batch.pos[0] = cur_pos++;
        batch.n_seq_id[0] = 1;
        batch.seq_id[0][0] = 0;
        batch.logits[0] = true;

        if (llama_decode(e->ctx, batch) != 0) break;
    }

    llama_sampler_free(sampler);
    llama_batch_free(batch);

    return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_aichat_LlamaEngine_nativeDestroy(JNIEnv*, jobject, jlong handle) {
    auto *e = reinterpret_cast<Engine*>(handle);
    if (!e) return;
    std::lock_guard<std::mutex> lock(e->mutex);
    if (e->ctx) llama_free(e->ctx);
    if (e->model) llama_model_free(e->model);
    llama_backend_free();
    delete e;
}
