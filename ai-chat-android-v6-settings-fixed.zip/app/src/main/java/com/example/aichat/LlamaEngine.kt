package com.example.aichat

import android.content.Context

data class EngineSettings(
    val contextSize: Int = 4096,
    val batchSize: Int = 512,
    val threads: Int = 0,
    val mmap: Boolean = true,
    val flashAttention: Int = -1, // -1 auto, 0 off, 1 on
    val kvType: String = "F16",
    val temperature: Float = 0.8f,
    val topK: Int = 40,
    val topP: Float = 0.95f,
    val minP: Float = 0.05f,
    val repeatPenalty: Float = 1.05f,
    val repeatLastN: Int = 64,
    val maxTokens: Int = 512,
    val seed: Long = -1L
) {
    companion object {
        const val PREFS = "engine_settings"

        fun from(context: Context): EngineSettings {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val ctx = p.getInt("context", 4096)
            val batch = p.getInt("batch", 512).coerceAtMost(ctx)
            return EngineSettings(
                contextSize = ctx,
                batchSize = batch,
                threads = p.getInt("threads", 0),
                mmap = p.getBoolean("mmap", true),
                flashAttention = p.getInt("flash", -1),
                kvType = p.getString("kv", "F16") ?: "F16",
                temperature = p.getFloat("temperature", 0.8f),
                topK = p.getInt("top_k", 40),
                topP = p.getFloat("top_p", 0.95f),
                minP = p.getFloat("min_p", 0.05f),
                repeatPenalty = p.getFloat("repeat_penalty", 1.05f),
                repeatLastN = p.getInt("repeat_last_n", 64),
                maxTokens = p.getInt("max_tokens", 512),
                seed = p.getLong("seed", -1L)
            )
        }

        fun save(context: Context, s: EngineSettings) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putInt("context", s.contextSize)
                .putInt("batch", s.batchSize.coerceAtMost(s.contextSize))
                .putInt("threads", s.threads)
                .putBoolean("mmap", s.mmap)
                .putInt("flash", s.flashAttention)
                .putString("kv", s.kvType)
                .putFloat("temperature", s.temperature)
                .putInt("top_k", s.topK)
                .putFloat("top_p", s.topP)
                .putFloat("min_p", s.minP)
                .putFloat("repeat_penalty", s.repeatPenalty)
                .putInt("repeat_last_n", s.repeatLastN)
                .putInt("max_tokens", s.maxTokens)
                .putLong("seed", s.seed)
                .apply()
        }
    }
}

class LlamaEngine(private val context: Context) {
    interface StreamCallback {
        fun onToken(token: String)
        fun onComplete()
        fun onError(message: String)
        fun onStats(generatedTokens: Int, promptTokens: Int, tokensPerSecond: Double)
    }

    companion object {
        init {
            System.loadLibrary("aichat")
        }
    }

    private val handle: Long = nativeCreate()

    fun load(path: String, settings: EngineSettings = EngineSettings.from(context)) {
        check(
            nativeLoad(
                handle,
                path,
                settings.contextSize,
                settings.batchSize.coerceAtMost(settings.contextSize),
                settings.threads,
                settings.mmap,
                settings.flashAttention,
                settings.kvType,
                settings.temperature,
                settings.topK,
                settings.topP,
                settings.minP,
                settings.repeatPenalty,
                settings.repeatLastN,
                settings.maxTokens,
                settings.seed
            )
        ) {
            "Não foi possível carregar o modelo."
        }
    }

    fun generateStreaming(
        messages: List<Pair<String, String>>,
        callback: StreamCallback
    ) {
        val roles = messages.map { it.first }.toTypedArray()
        val contents = messages.map { it.second }.toTypedArray()
        nativeGenerateStreaming(handle, roles, contents, callback)
    }

    protected fun finalize() {
        nativeDestroy(handle)
    }

    private external fun nativeCreate(): Long

    private external fun nativeLoad(
        handle: Long,
        path: String,
        contextSize: Int,
        batchSize: Int,
        threads: Int,
        mmap: Boolean,
        flashAttention: Int,
        kvType: String,
        temperature: Float,
        topK: Int,
        topP: Float,
        minP: Float,
        repeatPenalty: Float,
        repeatLastN: Int,
        maxTokens: Int,
        seed: Long
    ): Boolean

    private external fun nativeGenerateStreaming(
        handle: Long,
        roles: Array<String>,
        contents: Array<String>,
        callback: StreamCallback
    )

    private external fun nativeDestroy(handle: Long)
}
