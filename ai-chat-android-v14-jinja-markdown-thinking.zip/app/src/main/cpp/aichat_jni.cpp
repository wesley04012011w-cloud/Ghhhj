#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <chrono>
#include <cctype>
#include "llama.h"
#include "chat.h"

struct Engine {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    std::mutex mutex;
    float temperature = 0.6f;
    int top_k = 20;
    float top_p = 0.95f;
    float min_p = 0.0f;
    float repeat_penalty = 1.05f;
    int repeat_last_n = 64;
    int max_tokens = 512;
    uint32_t seed = LLAMA_DEFAULT_SEED;
};

static std::string jstring_to_string(JNIEnv *env, jstring s) {
    if (!s) return {};
    const char *p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}

static void callback_error(JNIEnv *env, jobject callback, const std::string & message) {
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onError", "(Ljava/lang/String;)V");
    if (method) {
        jstring msg = env->NewStringUTF(message.c_str());
        env->CallVoidMethod(callback, method, msg);
        env->DeleteLocalRef(msg);
    }
    env->DeleteLocalRef(cls);
}

static void callback_token(JNIEnv *env, jobject callback, const std::string & piece) {
    if (piece.empty()) return;
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onToken", "(Ljava/lang/String;)V");
    if (method) {
        jstring token = env->NewStringUTF(piece.c_str());
        env->CallVoidMethod(callback, method, token);
        env->DeleteLocalRef(token);
    }
    env->DeleteLocalRef(cls);
}

static void callback_thinking_start(JNIEnv *env, jobject callback) {
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onThinkingStart", "()V");
    if (method) env->CallVoidMethod(callback, method);
    env->DeleteLocalRef(cls);
}

static void callback_thinking(JNIEnv *env, jobject callback, const std::string & piece) {
    if (piece.empty()) return;
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onThinkingToken", "(Ljava/lang/String;)V");
    if (method) {
        jstring token = env->NewStringUTF(piece.c_str());
        env->CallVoidMethod(callback, method, token);
        env->DeleteLocalRef(token);
    }
    env->DeleteLocalRef(cls);
}

struct Utf8Stream {
    std::string pending;

    static bool is_cont(unsigned char c) {
        return (c & 0xC0) == 0x80;
    }

    // Returns the number of bytes in a complete UTF-8 code point at offset 0,
    // or 0 when more bytes are still needed. Invalid leading bytes are emitted
    // as a standalone byte only after they have been converted to U+FFFD by the
    // caller's fallback path.
    static size_t complete_len(const std::string & s) {
        if (s.empty()) return 0;
        const unsigned char c0 = static_cast<unsigned char>(s[0]);
        if (c0 < 0x80) return 1;
        size_t need = 0;
        if ((c0 & 0xE0) == 0xC0) need = 2;
        else if ((c0 & 0xF0) == 0xE0) need = 3;
        else if ((c0 & 0xF8) == 0xF0) need = 4;
        else return 1;
        if (s.size() < need) return 0;
        for (size_t i = 1; i < need; ++i) {
            if (!is_cont(static_cast<unsigned char>(s[i]))) return 1;
        }
        return need;
    }

    template <typename Fn>
    void feed(const std::string & bytes, Fn emit) {
        pending.append(bytes);
        while (!pending.empty()) {
            const size_t n = complete_len(pending);
            if (n == 0) break;
            emit(pending.substr(0, n));
            pending.erase(0, n);
        }
    }

    template <typename Fn>
    void finish(Fn emit) {
        if (pending.empty()) return;
        // A malformed/incomplete UTF-8 tail is not expected from llama.cpp,
        // but replacing it is safer than passing invalid bytes to JNI.
        emit("\xEF\xBF\xBD");
        pending.clear();
    }
};

struct ReasoningRouter {
    bool thinking = false;
    std::string pending;
    std::string start_tag = "<think>";
    std::string end_tag = "</think>";
    Utf8Stream utf8;

    void emit(JNIEnv *env, jobject callback, const std::string & text) {
        if (text.empty()) return;
        utf8.feed(text, [&](const std::string & safe) {
            if (thinking) callback_thinking(env, callback, safe);
            else callback_token(env, callback, safe);
        });
    }

    bool prefixOf(const std::string & tag, const std::string & s) const {
        return !tag.empty() && tag.rfind(s, 0) == 0;
    }

    void setTags(const std::string & start, const std::string & end, bool starts_inside_thinking = false) {
        if (!start.empty()) start_tag = start;
        if (!end.empty()) end_tag = end;
        // Some Jinja templates put <think> in the generation prompt itself.
        // In that case the first sampled token is already inside the reasoning
        // block and the model will only emit </think> at the transition.
        thinking = starts_inside_thinking;
    }

    void feed(JNIEnv *env, jobject callback, const std::string & piece) {
        if (start_tag.empty() && end_tag.empty()) {
            emit(env, callback, piece);
            return;
        }

        for (char c : piece) {
            pending.push_back(c);

            if (!start_tag.empty() && pending == start_tag) {
                thinking = true;
                pending.clear();
                continue;
            }
            if (!end_tag.empty() && pending == end_tag) {
                // Some Qwen3 turns intentionally contain an empty reasoning block:
                // </think> is emitted without visible reasoning text. Still signal
                // the UI so the Pensamento section is present rather than silently
                // disappearing.
                if (!thinking) {
                    callback_thinking(env, callback, "");
                }
                thinking = false;
                pending.clear();
                continue;
            }

            if (prefixOf(start_tag, pending) || prefixOf(end_tag, pending)) {
                continue;
            }

            while (!pending.empty()) {
                if (prefixOf(start_tag, pending) || prefixOf(end_tag, pending)) break;
                std::string one(1, pending.front());
                pending.erase(pending.begin());
                emit(env, callback, one);
            }
        }
    }

    void finish(JNIEnv *env, jobject callback) {
        if (!pending.empty()) {
            emit(env, callback, pending);
            pending.clear();
        }
        utf8.finish([&](const std::string & safe) {
            if (thinking) callback_thinking(env, callback, safe);
            else callback_token(env, callback, safe);
        });
    }
};

struct FormattedChat {
    std::string prompt;
    std::string thinkingStart;
    std::string thinkingEnd;
    std::string templateSource;
    bool supportsThinking = false;
    bool startsInsideThinking = false;
};

static bool apply_chat_template(
    llama_model * model,
    const std::vector<std::string> & roles,
    const std::vector<std::string> & contents,
    bool use_jinja,
    bool enable_thinking,
    FormattedChat & out
) {
    auto templates = common_chat_templates_init(model, "", "", "");
    if (!templates) return false;

    common_chat_templates_inputs inputs;
    inputs.add_generation_prompt = true;
    inputs.use_jinja = use_jinja;
    inputs.enable_thinking = enable_thinking;
    inputs.reasoning_format = COMMON_REASONING_FORMAT_DEEPSEEK;
    // Explicitly pass the same flag as chat_template_kwargs too. Qwen3-style
    // Jinja templates read enable_thinking from the template context; keeping
    // this explicit mirrors llama.cpp server behavior and avoids template
    // variants that only inspect chat_template_kwargs.
    inputs.chat_template_kwargs["enable_thinking"] = enable_thinking ? "true" : "false";
    inputs.chat_template_kwargs["preserve_reasoning"] = "true";

    inputs.messages.reserve(roles.size());
    for (size_t i = 0; i < roles.size(); ++i) {
        common_chat_msg msg;
        msg.role = roles[i];
        msg.content = contents[i];
        inputs.messages.push_back(std::move(msg));
    }

    // Qwen3 documents /think as the explicit per-turn switch. When the GGUF
    // template exposes that switch, use it as a belt-and-suspenders signal so
    // the model cannot silently fall back to an empty/non-thinking turn. Do
    // not touch other templates, and respect an explicit /no_think or /think
    // already present in the user's message.
    if (use_jinja && enable_thinking && !inputs.messages.empty() &&
        inputs.messages.back().role == "user" &&
        inputs.messages.back().content.find("/no_think") == std::string::npos &&
        inputs.messages.back().content.find("/think") == std::string::npos) {
        const std::string source = common_chat_templates_source(templates.get());
        const bool has_qwen_reasoning_switch =
            source.find("enable_thinking") != std::string::npos &&
            source.find("<think>") != std::string::npos &&
            source.find("</think>") != std::string::npos;
        if (has_qwen_reasoning_switch) {
            inputs.messages.back().content += "\n/think";
        }
    }

    const common_chat_params params = common_chat_templates_apply(templates.get(), inputs);
    if (params.prompt.empty()) return false;

    out.prompt = params.prompt;
    out.templateSource = common_chat_templates_source(templates.get());
    out.supportsThinking = params.supports_thinking;
    out.thinkingStart = params.thinking_start_tag;
    if (!params.thinking_end_tags.empty()) {
        out.thinkingEnd = params.thinking_end_tags.front();
    }

    // Qwen3 and several other reasoning templates use <think>...</think>.
    // Some versions of the template report the tags through common_chat,
    // while others only expose them in the rendered prompt. Handle both.
    if (out.thinkingStart.empty() &&
        (out.prompt.find("<think>") != std::string::npos || out.templateSource.find("<think>") != std::string::npos)) {
        out.thinkingStart = "<think>";
    }
    if (out.thinkingEnd.empty() &&
        (out.prompt.find("</think>") != std::string::npos || out.templateSource.find("</think>") != std::string::npos)) {
        out.thinkingEnd = "</think>";
    }
    if (!out.thinkingStart.empty() && !out.thinkingEnd.empty()) {
        std::string tail = out.prompt;
        while (!tail.empty() && std::isspace(static_cast<unsigned char>(tail.back()))) {
            tail.pop_back();
        }
        out.startsInsideThinking =
            tail.size() >= out.thinkingStart.size() &&
            tail.compare(tail.size() - out.thinkingStart.size(),
                         out.thinkingStart.size(),
                         out.thinkingStart) == 0;
    }
    return true;
}

static void callback_complete(JNIEnv *env, jobject callback) {
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onComplete", "()V");
    if (method) env->CallVoidMethod(callback, method);
    env->DeleteLocalRef(cls);
}

static void callback_stats(
    JNIEnv *env,
    jobject callback,
    int generated_tokens,
    int prompt_tokens,
    double tokens_per_second
) {
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onStats", "(IID)V");
    if (method) {
        env->CallVoidMethod(
            callback,
            method,
            static_cast<jint>(generated_tokens),
            static_cast<jint>(prompt_tokens),
            static_cast<jdouble>(tokens_per_second)
        );
    }
    env->DeleteLocalRef(cls);
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_aichat_LlamaEngine_nativeCreate(JNIEnv*, jobject) {
    llama_backend_init();
    auto *e = new Engine();
    return reinterpret_cast<jlong>(e);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_aichat_LlamaEngine_nativeLoad(
    JNIEnv *env,
    jobject,
    jlong handle,
    jstring path,
    jint context_size,
    jint batch_size,
    jint threads,
    jboolean use_mmap,
    jint flash_attention,
    jstring kv_type,
    jfloat temperature,
    jint top_k,
    jfloat top_p,
    jfloat min_p,
    jfloat repeat_penalty,
    jint repeat_last_n,
    jint max_tokens,
    jlong seed
) {
    auto *e = reinterpret_cast<Engine*>(handle);
    if (!e) return JNI_FALSE;

    std::lock_guard<std::mutex> lock(e->mutex);

    if (e->ctx) {
        llama_free(e->ctx);
        e->ctx = nullptr;
    }
    if (e->model) {
        llama_model_free(e->model);
        e->model = nullptr;
    }

    llama_model_params mp = llama_model_default_params();
    mp.load_mode = use_mmap ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_NONE;

    std::string p = jstring_to_string(env, path);
    e->model = llama_model_load_from_file(p.c_str(), mp);
    if (!e->model) return JNI_FALSE;

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(std::max(256, static_cast<int>(context_size)));
    cp.n_batch = static_cast<uint32_t>(std::max(32, std::min(static_cast<int>(cp.n_ctx), static_cast<int>(batch_size))));
    cp.n_ubatch = cp.n_batch;
    cp.n_threads = threads > 0 ? threads : 0;
    cp.n_threads_batch = threads > 0 ? threads : 0;

    if (flash_attention > 0) {
        cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    } else if (flash_attention == 0) {
        cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_DISABLED;
    } else {
        cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_AUTO;
    }

    e->temperature = std::max(0.0f, static_cast<float>(temperature));
    e->top_k = static_cast<int>(top_k);
    e->top_p = std::max(0.0f, std::min(1.0f, static_cast<float>(top_p)));
    e->min_p = std::max(0.0f, std::min(1.0f, static_cast<float>(min_p)));
    e->repeat_penalty = std::max(0.0f, static_cast<float>(repeat_penalty));
    e->repeat_last_n = std::max(0, static_cast<int>(repeat_last_n));
    e->max_tokens = std::max(1, static_cast<int>(max_tokens));
    e->seed = seed < 0 ? LLAMA_DEFAULT_SEED : static_cast<uint32_t>(seed);

    std::string kv = jstring_to_string(env, kv_type);
    if (kv == "Q8_0") {
        cp.type_k = GGML_TYPE_Q8_0;
        cp.type_v = GGML_TYPE_Q8_0;
    } else if (kv == "Q4_0") {
        cp.type_k = GGML_TYPE_Q4_0;
        cp.type_v = GGML_TYPE_Q4_0;
    } else {
        cp.type_k = GGML_TYPE_F16;
        cp.type_v = GGML_TYPE_F16;
    }

    e->ctx = llama_init_from_model(e->model, cp);
    if (!e->ctx) {
        llama_model_free(e->model);
        e->model = nullptr;
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_aichat_LlamaEngine_nativeGenerateStreaming(
    JNIEnv *env,
    jobject,
    jlong handle,
    jobjectArray jroles,
    jobjectArray jcontents,
    jboolean use_jinja,
    jboolean enable_thinking,
    jobject callback
) {
    auto *e = reinterpret_cast<Engine*>(handle);
    if (!e || !callback) return;

    std::lock_guard<std::mutex> lock(e->mutex);

    if (!e->model || !e->ctx) {
        callback_error(env, callback, "Modelo não carregado.");
        return;
    }

    const jsize role_count = env->GetArrayLength(jroles);
    const jsize content_count = env->GetArrayLength(jcontents);

    if (role_count <= 0 || role_count != content_count) {
        callback_error(env, callback, "Histórico de conversa inválido.");
        return;
    }

    std::vector<std::string> roles;
    std::vector<std::string> contents;
    roles.reserve(role_count);
    contents.reserve(content_count);

    for (jsize i = 0; i < role_count; ++i) {
        auto role = static_cast<jstring>(env->GetObjectArrayElement(jroles, i));
        auto content = static_cast<jstring>(env->GetObjectArrayElement(jcontents, i));

        roles.push_back(jstring_to_string(env, role));
        contents.push_back(jstring_to_string(env, content));

        if (role) env->DeleteLocalRef(role);
        if (content) env->DeleteLocalRef(content);
    }

    FormattedChat formatted;
    if (!apply_chat_template(e->model, roles, contents, use_jinja, enable_thinking, formatted)) {
        callback_error(env, callback,
                       "Não foi possível aplicar o template de conversa deste modelo.");
        return;
    }

    const llama_vocab *vocab = llama_model_get_vocab(e->model);

    const int n_prompt = -llama_tokenize(
        vocab,
        formatted.prompt.c_str(),
        formatted.prompt.size(),
        nullptr,
        0,
        true,
        true
    );

    if (n_prompt <= 0) {
        callback_error(env, callback, "Não consegui tokenizar o prompt.");
        return;
    }

    std::vector<llama_token> tokens(static_cast<size_t>(n_prompt));

    if (llama_tokenize(
            vocab,
            formatted.prompt.c_str(),
            formatted.prompt.size(),
            tokens.data(),
            tokens.size(),
            true,
            true
        ) < 0) {
        callback_error(env, callback, "Falha ao tokenizar o prompt.");
        return;
    }

    llama_memory_clear(llama_get_memory(e->ctx), true);

    llama_batch batch = llama_batch_init(512, 0, 1);

    if (tokens.size() > 512) {
        llama_batch_free(batch);
        callback_error(env, callback,
                       "O prompt ficou grande demais para o lote atual.");
        return;
    }

    for (size_t i = 0; i < tokens.size(); ++i) {
        batch.token[i] = tokens[i];
        batch.pos[i] = static_cast<llama_pos>(i);
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == tokens.size() - 1);
    }
    batch.n_tokens = static_cast<int32_t>(tokens.size());

    if (llama_decode(e->ctx, batch) != 0) {
        llama_batch_free(batch);
        callback_error(env, callback, "Falha no decode inicial.");
        return;
    }

    // Sampling settings are captured when the model is loaded.
    // Keep the chain simple and deterministic in order: penalties -> top-k -> top-p -> min-p -> temperature -> RNG.
    llama_sampler_chain_params sp = llama_sampler_chain_default_params();
    llama_sampler *sampler = llama_sampler_chain_init(sp);

    if (!sampler) {
        llama_batch_free(batch);
        callback_error(env, callback, "Falha ao criar o sampler.");
        return;
    }

    const llama_vocab * sampler_vocab = llama_model_get_vocab(e->model);
    const int n_vocab = llama_vocab_n_tokens(sampler_vocab);

    if (e->repeat_last_n > 0 && e->repeat_penalty != 1.0f) {
        llama_sampler_chain_add(
            sampler,
            llama_sampler_init_penalties(
                n_vocab,
                e->repeat_last_n,
                e->repeat_penalty,
                0.0f,
                0.0f
            )
        );
    }

    if (e->top_k > 0) {
        llama_sampler_chain_add(sampler, llama_sampler_init_top_k(e->top_k));
    }

    if (e->top_p < 1.0f) {
        llama_sampler_chain_add(sampler, llama_sampler_init_top_p(e->top_p, 1));
    }

    if (e->min_p > 0.0f) {
        llama_sampler_chain_add(sampler, llama_sampler_init_min_p(e->min_p, 1));
    }

    llama_sampler_chain_add(sampler, llama_sampler_init_temp(e->temperature));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(e->seed));

    int cur_pos = static_cast<int>(tokens.size());
    const int max_new_tokens = std::max(1, e->max_tokens);
    int generated_tokens = 0;
    const auto generation_start = std::chrono::steady_clock::now();
    ReasoningRouter reasoning_router;
    // Qwen3-style templates can prefill the assistant message with <think>
    // and the actual sampled stream starts already inside the reasoning block.
    // common_chat reports this through supports_thinking, while some template
    // versions expose the literal tag only in the rendered prompt. Treat both
    // cases as the same state so the UI receives reasoning from token 1.
    const bool starts_thinking = formatted.startsInsideThinking;
    reasoning_router.setTags(formatted.thinkingStart, formatted.thinkingEnd, starts_thinking);
    if (starts_thinking) {
        callback_thinking_start(env, callback);
    }

    for (int i = 0; i < max_new_tokens; ++i) {
        llama_token token = llama_sampler_sample(sampler, e->ctx, -1);

        if (llama_vocab_is_eog(vocab, token)) {
            break;
        }

        char piece[4096];
        int len = llama_token_to_piece(
            vocab,
            token,
            piece,
            sizeof(piece),
            0,
            true
        );

        if (len > 0) {
            reasoning_router.feed(env, callback, std::string(piece, len));
        }

        llama_sampler_accept(sampler, token);
        ++generated_tokens;

        const auto elapsed = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - generation_start
        ).count();
        const double tps = elapsed > 0.0
            ? static_cast<double>(generated_tokens) / elapsed
            : 0.0;
        callback_stats(env, callback, generated_tokens, n_prompt, tps);

        batch.n_tokens = 1;
        batch.token[0] = token;
        batch.pos[0] = cur_pos++;
        batch.n_seq_id[0] = 1;
        batch.seq_id[0][0] = 0;
        batch.logits[0] = true;

        if (llama_decode(e->ctx, batch) != 0) {
            llama_sampler_free(sampler);
            llama_batch_free(batch);
            callback_error(env, callback, "Falha durante a geração.");
            return;
        }
    }

    reasoning_router.finish(env, callback);

    llama_sampler_free(sampler);
    llama_batch_free(batch);

    callback_complete(env, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_aichat_LlamaEngine_nativeUnload(
    JNIEnv*,
    jobject,
    jlong handle
) {
    auto *e = reinterpret_cast<Engine*>(handle);
    if (!e) return;
    std::lock_guard<std::mutex> lock(e->mutex);
    if (e->ctx) {
        llama_free(e->ctx);
        e->ctx = nullptr;
    }
    if (e->model) {
        llama_model_free(e->model);
        e->model = nullptr;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_aichat_LlamaEngine_nativeDestroy(JNIEnv*, jobject, jlong handle) {
    auto *e = reinterpret_cast<Engine*>(handle);
    if (!e) return;

    std::lock_guard<std::mutex> lock(e->mutex);

    if (e->ctx) llama_free(e->ctx);
    if (e->model) llama_model_free(e->model);

    llama_backend_free();
    delete e;
}
