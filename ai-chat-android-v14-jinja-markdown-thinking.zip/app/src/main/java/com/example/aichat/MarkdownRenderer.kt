package com.example.aichat

import android.text.Html
import android.text.Spanned
import android.widget.TextView
import java.util.regex.Pattern

/** Lightweight Markdown renderer for chat messages.
 *
 * Important: fenced/inline code is extracted BEFORE HTML escaping.  Escaping the
 * whole message first and then escaping code again turns < into visible &lt;.
 */
object MarkdownRenderer {
    private data class CodeBlock(val language: String, val code: String)

    fun render(text: String): Spanned {
        var source = text.replace("\r\n", "\n").replace("\r", "\n")

        // Protect fenced code before any Markdown/HTML transformation.
        val fenced = mutableListOf<CodeBlock>()
        val fencePattern = Pattern.compile("(?s)```([^\\n`]*)\\n?(.*?)```")
        val fenceMatcher = fencePattern.matcher(source)
        val fenceOut = StringBuffer()
        while (fenceMatcher.find()) {
            val language = fenceMatcher.group(1)?.trim().orEmpty()
            val code = fenceMatcher.group(2).orEmpty()
            val index = fenced.size
            fenced += CodeBlock(language, code)
            fenceMatcher.appendReplacement(fenceOut, "§§FENCE$index§§")
        }
        fenceMatcher.appendTail(fenceOut)
        source = fenceOut.toString()

        // Protect inline code too, so **inside `code`** is never interpreted.
        val inlineCodes = mutableListOf<String>()
        val inlinePattern = Pattern.compile("`([^`\\n]+)`")
        val inlineMatcher = inlinePattern.matcher(source)
        val inlineOut = StringBuffer()
        while (inlineMatcher.find()) {
            val index = inlineCodes.size
            inlineCodes += inlineMatcher.group(1).orEmpty()
            inlineMatcher.appendReplacement(inlineOut, "§§INLINE$index§§")
        }
        inlineMatcher.appendTail(inlineOut)
        source = inlineOut.toString()

        var s = escapeHtml(source)

        // Tables: consecutive Markdown rows with a separator row.
        val lines = s.split("\n")
        val out = StringBuilder()
        var i = 0
        while (i < lines.size) {
            if (i + 1 < lines.size && isTableSeparator(lines[i + 1])) {
                val header = splitTableRow(lines[i])
                val separator = splitTableRow(lines[i + 1])
                if (header.isNotEmpty() && separator.size == header.size) {
                    out.append("<br><b>")
                    out.append(header.joinToString("  |  "))
                    out.append("</b><br>")
                    out.append(header.joinToString("  |  ") { "—".repeat(maxOf(3, it.length.coerceAtMost(12))) })
                    out.append("<br>")
                    i += 2
                    while (i < lines.size && lines[i].contains("|")) {
                        val cells = splitTableRow(lines[i])
                        if (cells.size != header.size) break
                        out.append(cells.joinToString("  |  ")).append("<br>")
                        i++
                    }
                    out.append("<br>\n")
                    continue
                }
            }
            out.append(lines[i]).append("\n")
            i++
        }
        s = out.toString()

        // Headings.
        s = s.replace(Regex("(?m)^###### (.+)$"), "<b><small>$1</small></b>")
            .replace(Regex("(?m)^##### (.+)$"), "<b>$1</b>")
            .replace(Regex("(?m)^#### (.+)$"), "<b>$1</b>")
            .replace(Regex("(?m)^### (.+)$"), "<b><big>$1</big></b>")
            .replace(Regex("(?m)^## (.+)$"), "<b><big>$1</big></b>")
            .replace(Regex("(?m)^# (.+)$"), "<b><big>$1</big></b>")

        // Lists.
        s = s.replace(Regex("(?m)^\\s*[-*] (.+)$"), "• $1")
        s = s.replace(Regex("(?m)^\\s*(\\d+)\\. (.+)$"), "$1. $2")

        // Blockquotes.
        s = s.replace(Regex("(?m)^&gt; ?(.+)$"), "<font color=\"#A0A0A0\">▌ $1</font>")

        // Bold, strike and italic.
        s = s.replace(Regex("\\*\\*([^*]+)\\*\\*|__([^_]+)__")) { m ->
            "<b>${m.groupValues[1].ifEmpty { m.groupValues[2] }}</b>"
        }
        s = s.replace(Regex("~~([^~]+)~~"), "<s>$1</s>")
        s = s.replace(Regex("(?<!\\*)\\*([^*]+)\\*(?!\\*)|(?<!_)_([^_]+)_(?!_)")) { m ->
            "<i>${m.groupValues[1].ifEmpty { m.groupValues[2] }}</i>"
        }

        // Preserve newlines as HTML line breaks.
        s = s.replace("\n", "<br>")

        // Restore inline/fenced code. The source was escaped exactly once.
        inlineCodes.forEachIndexed { index, code ->
            val safe = escapeHtml(code).replace("\n", "<br>")
            s = s.replace(
                "§§INLINE$index§§",
                "<font color=\"#E8E8E8\"><tt>$safe</tt></font>"
            )
        }
        fenced.forEachIndexed { index, block ->
            val safe = escapeHtml(block.code).replace("\n", "<br>")
            val lang = if (block.language.isNotEmpty()) {
                "<br><small>${escapeHtml(block.language)}</small>"
            } else ""
            s = s.replace(
                "§§FENCE$index§§",
                "<font color=\"#E8E8E8\"><tt>$safe</tt></font>$lang"
            )
        }

        return Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY)
    }

    fun apply(view: TextView, text: String) {
        view.text = render(text)
    }

    private fun escapeHtml(text: String): String =
        text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun splitTableRow(line: String): List<String> =
        line.trim().trim('|').split("|").map { it.trim() }

    private fun isTableSeparator(line: String): Boolean =
        line.contains("|") && splitTableRow(line).all { it.matches(Regex(":?-{3,}:?")) }
}
