import React, {useEffect, useMemo, useRef, useState} from 'react';
import {Alert, KeyboardAvoidingView, Platform, Pressable, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, View} from 'react-native';
import {NativeAI, subscribeStream} from './native';

type Message = {role: 'user' | 'assistant'; content: string};

const colors = {bg:'#07090d', panel:'#0d1118', panel2:'#111722', border:'#202938', text:'#f4f7fb', muted:'#8b96a8', accent:'#8b5cf6', cyan:'#42d7ff', green:'#35d07f', blue:'#4ea1ff'};

function Icon({kind}: {kind:'plus'|'send'|'brain'|'menu'|'chevron'}) {
  if (kind === 'plus') return <View style={icon.plus}><View style={icon.h}/><View style={icon.v}/></View>;
  if (kind === 'send') return <View style={icon.send}><View style={icon.sendHead}/><View style={icon.sendTail}/></View>;
  if (kind === 'menu') return <View style={icon.menu}><View/><View/><View/></View>;
  if (kind === 'chevron') return <Text style={icon.chevron}>⌄</Text>;
  return <View style={icon.brain}><View style={icon.brainLine}/><View style={icon.brainDot}/></View>;
}

export default function App() {
  const [models, setModels] = useState<string[]>([]);
  const [model, setModel] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [thinking, setThinking] = useState('');
  const [answer, setAnswer] = useState('');
  const [thinkingOpen, setThinkingOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [menu, setMenu] = useState(false);
  const thinkingMode = useRef(false);
  const parserBuffer = useRef('');

  const appendThinking = (text: string) => setThinking(prev => prev + text);
  const appendAnswer = (text: string) => setAnswer(prev => prev + text);

  const routeToken = (token: string) => {
    parserBuffer.current += token;
    const tags = ['<think>', '<thinking>', '<reasoning>', '<analysis>', '</think>', '</thinking>', '</reasoning>', '</analysis>'];
    while (parserBuffer.current.length) {
      let foundTag = '';
      let foundAt = -1;
      for (const tag of tags) {
        const at = parserBuffer.current.indexOf(tag);
        if (at >= 0 && (foundAt < 0 || at < foundAt)) { foundAt = at; foundTag = tag; }
      }
      if (foundAt < 0) {
        const keep = Math.max(...tags.map(t => Math.min(parserBuffer.current.length, t.length - 1)));
        const safeLen = Math.max(0, parserBuffer.current.length - keep);
        const safe = parserBuffer.current.slice(0, safeLen);
        parserBuffer.current = parserBuffer.current.slice(safeLen);
        if (safe) (thinkingMode.current ? appendThinking : appendAnswer)(safe);
        break;
      }
      const before = parserBuffer.current.slice(0, foundAt);
      if (before) (thinkingMode.current ? appendThinking : appendAnswer)(before);
      parserBuffer.current = parserBuffer.current.slice(foundAt + foundTag.length);
      if (foundTag.startsWith('</')) { thinkingMode.current = false; } else { thinkingMode.current = true; setThinkingOpen(true); }
    }
  };

  useEffect(() => {
    NativeAI.listModels().then(setModels).catch(() => {});
    const sub = subscribeStream(e => {
      if (e.type === 'thinkingStart') { thinkingMode.current = true; setThinkingOpen(true); return; }
      if (e.type === 'token') { routeToken(e.token);
      } else if (e.type === 'complete') {
        if (parserBuffer.current) { (thinkingMode.current ? appendThinking : appendAnswer)(parserBuffer.current); parserBuffer.current = ''; }
        setBusy(false); setThinkingOpen(false);
        if (answer) setMessages(prev => [...prev, {role:'assistant', content: answer}]);
        setAnswer(''); setThinking('');
      } else if (e.type === 'error') {
        setBusy(false); Alert.alert('AI Chat', e.message);
      }
    });
    return () => sub.remove();
  }, []);

  const load = async (path: string) => {
    try { await NativeAI.loadModel(path); setModel(path); }
    catch (e) { Alert.alert('Modelo', String(e)); }
  };

  const pick = async () => {
    try { const path = await NativeAI.pickModel(); if (path) { await load(path); setModels(await NativeAI.listModels()); } }
    catch (e) { Alert.alert('Modelo', String(e)); }
  };

  const send = async () => {
    const text = input.trim();
    if (!text || busy || !model) return;
    const next = [...messages, {role:'user' as const, content:text}];
    setMessages(next); setInput(''); setThinking(''); setAnswer(''); setBusy(true); setThinkingOpen(false); thinkingMode.current = false; parserBuffer.current = '';
    try { await NativeAI.generate(next); } catch (e) { setBusy(false); Alert.alert('Geração', String(e)); }
  };

  const displayMessages = useMemo(() => messages, [messages]);

  return <SafeAreaView style={styles.root}>
    <StatusBar barStyle="light-content" backgroundColor={colors.bg}/>
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.header}>
        <Pressable onPress={() => setMenu(!menu)} style={styles.iconButton}><Icon kind="menu"/></Pressable>
        <View style={styles.titleWrap}><Text style={styles.title}>AI Chat</Text><Text style={styles.subtitle}>{model ? model.split('/').pop() : 'No model loaded'}</Text></View>
        <Pressable onPress={pick} style={styles.modelButton}><Text style={styles.modelButtonText}>Models</Text></Pressable>
      </View>
      {menu && <View style={styles.drawer}><Text style={styles.drawerTitle}>Chats</Text><Text style={styles.drawerItem}>New conversation</Text><Text style={styles.drawerItem}>Models</Text><Text style={styles.drawerItem}>Settings</Text></View>}
      <ScrollView style={styles.chat} contentContainerStyle={styles.chatContent} keyboardShouldPersistTaps="handled">
        {displayMessages.map((m, i) => <View key={i} style={[styles.bubble, m.role === 'user' ? styles.userBubble : styles.aiBubble]}><Text style={styles.message}>{m.content}</Text></View>)}
        {thinking.length > 0 && <Pressable onPress={() => setThinkingOpen(!thinkingOpen)} style={styles.thinkingBox}>
          <View style={styles.thinkingHeader}><Icon kind="brain"/><Text style={styles.thinkingTitle}>Thinking</Text><Icon kind="chevron"/></View>
          {thinkingOpen && <Text style={styles.thinkingText}>{thinking}</Text>}
        </Pressable>}
        {answer.length > 0 && <View style={styles.bubble}><Text style={styles.message}>{answer}</Text></View>}
      </ScrollView>
      <View style={styles.composerShell}>
        <Pressable onPress={pick} style={styles.addButton}><Icon kind="plus"/></Pressable>
        <TextInput value={input} onChangeText={setInput} placeholder="Ask assistant..." placeholderTextColor="#657082" multiline maxLength={12000} style={styles.input} returnKeyType="send" onSubmitEditing={send}/>
        <Pressable onPress={send} style={[styles.sendButton, (!input.trim() || busy || !model) && styles.sendDisabled]}><Icon kind="send"/></Pressable>
      </View>
    </KeyboardAvoidingView>
  </SafeAreaView>;
}

const icon = StyleSheet.create({plus:{width:20,height:20,justifyContent:'center',alignItems:'center'},h:{position:'absolute',width:14,height:2,borderRadius:2,backgroundColor:'#f5f7fb'},v:{position:'absolute',width:2,height:14,borderRadius:2,backgroundColor:'#f5f7fb'},send:{width:20,height:20,position:'relative'},sendHead:{position:'absolute',right:2,top:4,width:11,height:11,borderTopWidth:2,borderRightWidth:2,borderColor:'#111722',transform:[{rotate:45+'deg'}]},sendTail:{position:'absolute',left:2,top:9,width:14,height:2,borderRadius:2,backgroundColor:'#111722',transform:[{rotate:-20+'deg'}]},menu:{width:20,height:18,justifyContent:'space-between'},chevron:{color:'#b9c2d0',fontSize:18,lineHeight:18},brain:{width:20,height:20,borderWidth:2,borderColor:'#fff',borderRadius:10,position:'relative'},brainLine:{position:'absolute',left:8,top:2,width:2,height:12,backgroundColor:'#fff'},brainDot:{position:'absolute',left:3,top:8,width:2,height:2,borderRadius:1,backgroundColor:'#fff'}});
const styles = StyleSheet.create({root:{flex:1,backgroundColor:colors.bg},flex:{flex:1},header:{height:66,flexDirection:'row',alignItems:'center',paddingHorizontal:14,borderBottomWidth:1,borderBottomColor:colors.border},iconButton:{width:40,height:40,borderRadius:12,backgroundColor:colors.panel2,alignItems:'center',justifyContent:'center'},titleWrap:{flex:1,marginLeft:12},title:{color:colors.text,fontSize:18,fontWeight:'700'},subtitle:{color:colors.muted,fontSize:11,marginTop:2},modelButton:{paddingHorizontal:14,paddingVertical:9,borderRadius:14,backgroundColor:'#17243a'},modelButtonText:{color:colors.cyan,fontWeight:'700'},drawer:{position:'absolute',zIndex:10,left:10,top:58,width:220,padding:14,borderRadius:18,backgroundColor:colors.panel,borderWidth:1,borderColor:colors.border},drawerTitle:{color:colors.text,fontWeight:'800',fontSize:16,marginBottom:12},drawerItem:{color:colors.muted,paddingVertical:9},chat:{flex:1},chatContent:{padding:16,gap:12},bubble:{maxWidth:'92%',alignSelf:'flex-start',backgroundColor:colors.panel2,borderRadius:18,paddingHorizontal:14,paddingVertical:11,borderWidth:1,borderColor:colors.border},userBubble:{alignSelf:'flex-end',backgroundColor:'#17243a',borderColor:'#263e63'},aiBubble:{alignSelf:'flex-start'},message:{color:colors.text,fontSize:15.5,lineHeight:23},thinkingBox:{backgroundColor:'#161b24',borderColor:'#f2f5f8',borderWidth:1,borderRadius:16,padding:12},thinkingHeader:{flexDirection:'row',alignItems:'center',gap:9},thinkingTitle:{color:'#fff',fontWeight:'800',flex:1},thinkingText:{color:'#b7c0cc',marginTop:10,lineHeight:20},composerShell:{minHeight:56,maxHeight:150,margin:10,padding:7,borderRadius:20,borderWidth:1,borderColor:colors.border,backgroundColor:colors.panel,flexDirection:'row',alignItems:'flex-end'},addButton:{width:40,height:40,borderRadius:14,backgroundColor:colors.panel2,alignItems:'center',justifyContent:'center',marginRight:5},input:{flex:1,minHeight:40,maxHeight:130,color:colors.text,fontSize:16,paddingHorizontal:8,paddingVertical:7},sendButton:{width:40,height:40,borderRadius:20,backgroundColor:'#f6f8fa',alignItems:'center',justifyContent:'center',marginLeft:5},sendDisabled:{opacity:.45}});
