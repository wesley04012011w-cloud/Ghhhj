import {NativeModules, DeviceEventEmitter, EmitterSubscription} from 'react-native';

type Native = {
  pickModel(): Promise<string | null>;
  listModels(): Promise<string[]>;
  loadModel(path: string): Promise<boolean>;
  unloadModel(): Promise<boolean>;
  generate(messages: {role: string; content: string}[]): Promise<boolean>;
};

export const NativeAI = NativeModules.AIChat as Native;

export type StreamEvent =
  | {type: 'token'; token: string}
  | {type: 'thinkingStart'}
  | {type: 'complete'}
  | {type: 'error'; message: string}
  | {type: 'stats'; generatedTokens: number; promptTokens: number; tokensPerSecond: number};

export function subscribeStream(listener: (event: StreamEvent) => void): EmitterSubscription {
  return DeviceEventEmitter.addListener('AIChatStream', listener);
}
