# Keep JNI callback methods discoverable.
-keep class com.aichat.LlamaEngine { *; }
