#include <jni.h>
#include <string>
#include <mutex>
#include <fstream>
#include "llama.h"

static std::mutex g_mutex;
static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static std::string g_path;
static bool g_stop = false;

static jstring js(JNIEnv* env, const std::string& s) {
    return env->NewStringUTF(s.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_localpal_app_LocalLlmPlugin_nativeLoadModel(JNIEnv* env, jobject, jstring jpath, jint context, jint threads, jint batch, jint gpuLayers, jboolean flash, jboolean mmap, jboolean mlock, jboolean numa) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    g_path = path;
    env->ReleaseStringUTFChars(jpath, path);

    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }

    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = gpuLayers;
    mp.use_mmap = mmap;
    mp.use_mlock = mlock;

    g_model = llama_model_load_from_file(g_path.c_str(), mp);
    if (!g_model) return js(env, R"({"error":"llama_model_load_from_file falhou"})");

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = context;
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    cp.n_batch = batch;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        llama_model_free(g_model); g_model = nullptr;
        return js(env, R"({"error":"llama_init_from_model falhou"})");
    }

    nlohmann::json out = {{"id",g_path},{"name",g_path.substr(g_path.find_last_of("/\\")+1)},{"path",g_path},{"sizeBytes",0},{"context",context},{"loaded",true},{"flashAttention",bool(flash)},{"numa",bool(numa)}};
    return js(env, out.dump());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_localpal_app_LocalLlmPlugin_nativeUnload(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) llama_free(g_ctx);
    if (g_model) llama_model_free(g_model);
    g_ctx = nullptr; g_model = nullptr;
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_localpal_app_LocalLlmPlugin_nativeGenerate(JNIEnv* env, jobject, jstring jprompt, jfloat temperature, jfloat topP, jint topK, jfloat minP, jfloat repeatPenalty, jint seed, jboolean thinking, jboolean jinja) {
    (void)temperature; (void)topP; (void)topK; (void)repeatPenalty; (void)minP; (void)seed; (void)thinking; (void)jinja;
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_ctx || !g_model) return js(env, R"({"error":"Nenhum modelo carregado"})");

    const char* prompt = env->GetStringUTFChars(jprompt, nullptr);
    std::string raw(prompt);
    env->ReleaseStringUTFChars(jprompt, prompt);

    // Adapter MVP: mantém a API do app independente da montagem do chat template.
    // A próxima camada deve transformar o JSON de mensagens em prompt usando
    // llama_model_chat_template()/Jinja da versão pinada do llama.cpp.
    //
    // Para evitar acoplamento a APIs que mudam entre commits, esta base retorna
    // o payload preparado. O ponto de integração de sampling fica aqui.
    return js(env, "Motor carregado. Prompt recebido: " + raw.substr(0, 120));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_localpal_app_LocalLlmPlugin_nativeStop(JNIEnv*, jobject) {
    g_stop = true;
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_localpal_app_LocalLlmPlugin_nativeModelInfo(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model) return js(env, "null");
    return js(env, std::string(R"({"loaded":true,"path":")") + g_path + "\"}");
}
