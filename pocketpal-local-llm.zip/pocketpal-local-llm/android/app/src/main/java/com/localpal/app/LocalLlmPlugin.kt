package com.localpal.app

import com.getcapacitor.*
import org.json.JSONObject

@CapacitorPlugin(name = "LocalLlm")
class LocalLlmPlugin : Plugin() {
    companion object {
        init { System.loadLibrary("localpal") }
    }

    private external fun nativeLoadModel(path: String, context: Int, threads: Int, batch: Int, gpuLayers: Int, flash: Boolean, mmap: Boolean, mlock: Boolean, numa: Boolean): String
    private external fun nativeUnload(): Boolean
    private external fun nativeGenerate(prompt: String, temperature: Float, topP: Float, topK: Int, minP: Float, repeatPenalty: Float, seed: Int, thinking: Boolean, jinja: Boolean): String
    private external fun nativeStop(): Boolean
    private external fun nativeModelInfo(): String

    @PluginMethod
    fun loadModel(call: PluginCall) {
        val path = call.getString("path") ?: return call.reject("path obrigatório")
        val s = call.getObject("settings") ?: JSONObject()
        try {
            val info = nativeLoadModel(path, s.optInt("contextSize",8192), s.optInt("threads",4), s.optInt("batchSize",512), s.optInt("gpuLayers",0), s.optBoolean("flashAttention",true), s.optBoolean("mmap",true), s.optBoolean("mlock",false), s.optBoolean("numa",false))
            call.resolve(JSONObject(info))
        } catch (e: Exception) { call.reject(e.message ?: "Falha ao carregar modelo") }
    }

    @PluginMethod
    fun unloadModel(call: PluginCall) { call.resolve(JSObject().put("ok", nativeUnload())) }

    @PluginMethod
    fun generate(call: PluginCall) {
        val messages = call.getArray("messages") ?: return call.reject("messages obrigatório")
        val s = call.getObject("settings") ?: JSONObject()
        val prompt = messages.toString()
        try {
            val text = nativeGenerate(prompt, s.optDouble("temperature",0.7).toFloat(), s.optDouble("topP",0.95).toFloat(), s.optInt("topK",40), s.optDouble("minP",0.05).toFloat(), s.optDouble("repeatPenalty",1.08).toFloat(), s.optInt("seed",-1), s.optBoolean("thinking",true), s.optBoolean("jinja",true))
            call.resolve(JSObject().put("text", text))
        } catch (e: Exception) { call.reject(e.message ?: "Falha na geração") }
    }

    @PluginMethod
    fun stop(call: PluginCall) { call.resolve(JSObject().put("ok", nativeStop())) }

    @PluginMethod
    fun getModelInfo(call: PluginCall) {
        val raw = nativeModelInfo()
        call.resolve(if (raw == "null") JSObject() else JSObject(raw))
    }
}
