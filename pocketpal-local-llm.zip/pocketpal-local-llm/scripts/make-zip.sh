#!/usr/bin/env bash
set -euo pipefail
rm -f pocketpal-local-llm.zip
zip -qr pocketpal-local-llm.zip . \
  -x 'pocketpal-local-llm.zip' \
     '.git/*' \
     'node_modules/*' \
     'dist/*' \
     'android/.gradle/*' \
     'android/app/build/*' \
     'third_party/*'
echo "Created pocketpal-local-llm.zip"
