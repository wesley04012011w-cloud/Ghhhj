import { registerPlugin } from '@capacitor/core';

export interface ModelInfo {
  id: string;
  name: string;
  path: string;
  sizeBytes: number;
  context: number;
  loaded: boolean;
}

export interface LlmSettings {
  contextSize: number;
  threads: number;
  batchSize: number;
  gpuLayers: number;
  temperature: number;
  topP: number;
  topK: number;
  minP: number;
  repeatPenalty: number;
  seed: number;
  flashAttention: boolean;
  mmap: boolean;
  mlock: boolean;
  numa: boolean;
  thinking: boolean;
  jinja: boolean;
}

interface LocalLlmPlugin {
  loadModel(options: { path: string; settings: LlmSettings }): Promise<ModelInfo>;
  unloadModel(): Promise<void>;
  generate(options: { messages: { role: string; content: string }[]; settings: LlmSettings }): Promise<{ text: string }>;
  stop(): Promise<void>;
  getModelInfo(): Promise<ModelInfo | null>;
}

export const LocalLlm = registerPlugin<LocalLlmPlugin>('LocalLlm');
