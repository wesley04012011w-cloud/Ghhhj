import { useEffect, useMemo, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Settings2, Cpu, Plus, Send, SlidersHorizontal, BrainCircuit, FileBox, Menu, X } from 'lucide-react';
import { LocalLlm, LlmSettings } from './engine';

type Message = { role: 'user'|'assistant'|'system'; content: string; thinking?: string };

const defaultSettings: LlmSettings = {
  contextSize: 8192, threads: 6, batchSize: 512, gpuLayers: 0,
  temperature: 0.7, topP: 0.95, topK: 40, minP: 0.05, repeatPenalty: 1.08,
  seed: -1, flashAttention: true, mmap: true, mlock: false, numa: false,
  thinking: true, jinja: true
};

function App() {
  const [drawer, setDrawer] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settings, setSettings] = useState<LlmSettings>(() => {
    try { return JSON.parse(localStorage.getItem('localpal-settings') || 'null') || defaultSettings; }
    catch { return defaultSettings; }
  });
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Olá! Sou seu modelo local. **Nada precisa sair do aparelho.**\\n\\nCarregue um `.gguf` para começar.' }
  ]);
  const [input, setInput] = useState('');
  const [model, setModel] = useState('Nenhum modelo carregado');
  const [busy, setBusy] = useState(false);

  useEffect(() => localStorage.setItem('localpal-settings', JSON.stringify(settings)), [settings]);

  const canSend = useMemo(() => input.trim().length > 0 && !busy, [input, busy]);

  async function chooseModel() {
    // SAF: o plugin nativo pode abrir o seletor de documentos.
    const path = window.prompt('Caminho do arquivo GGUF (modo dev):');
    if (!path) return;
    try {
      const info = await LocalLlm.loadModel({ path, settings });
      setModel(info.name || path.split('/').pop() || 'Modelo');
    } catch (e) {
      alert(`Não foi possível carregar o modelo: ${String(e)}`);
    }
  }

  async function send() {
    if (!canSend) return;
    const user = input.trim();
    setInput('');
    const next = [...messages, { role: 'user' as const, content: user }];
    setMessages(next);
    setBusy(true);
    try {
      const result = await LocalLlm.generate({ messages: next.map(({role, content}) => ({role, content})), settings });
      setMessages(prev => [...prev, { role: 'assistant', content: result.text }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', content: `Erro no motor local: ${String(e)}` }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${drawer ? 'open' : ''}`}>
        <div className="brand"><div className="brand-mark">P</div><div><b>LocalPal</b><span>local AI studio</span></div></div>
        <button className="new-chat" onClick={() => setMessages([])}><Plus size={18}/> Novo chat</button>
        <div className="side-section">
          <small>WORKSPACE</small>
          <button><FileBox size={17}/> Modelos</button>
          <button onClick={() => setSettingsOpen(true)}><Settings2 size={17}/> Configurações</button>
        </div>
        <div className="privacy-card"><Cpu size={18}/><div><b>Local-first</b><span>Inferência no dispositivo</span></div></div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="icon-btn mobile-only" onClick={() => setDrawer(v=>!v)}>{drawer ? <X/> : <Menu/>}</button>
          <div className="model-chip"><span className={`dot ${model !== 'Nenhum modelo carregado' ? 'on':''}`}></span>{model}</div>
          <button className="load-btn" onClick={chooseModel}><Plus size={17}/> Carregar GGUF</button>
          <button className="icon-btn" onClick={() => setSettingsOpen(true)}><SlidersHorizontal/></button>
        </header>

        <section className="chat">
          {messages.map((m, i) => (
            <article className={`message ${m.role}`} key={i}>
              <div className="avatar">{m.role === 'user' ? 'Você' : 'AI'}</div>
              <div className="bubble">
                {m.thinking && <details className="thinking"><summary><BrainCircuit size={15}/> Thinking</summary><div>{m.thinking}</div></details>}
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
              </div>
            </article>
          ))}
          {busy && <div className="typing"><span/><span/><span/></div>}
        </section>

        <footer className="composer-wrap">
          <div className="composer">
            <textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}} placeholder="Mensagem para seu modelo local..." rows={1}/>
            <button className="send" disabled={!canSend} onClick={send}><Send size={18}/></button>
          </div>
          <div className="composer-hint">Enter envia · Shift+Enter quebra linha · <b>{settings.contextSize.toLocaleString()} ctx</b> · {settings.threads} threads</div>
        </footer>
      </main>

      {settingsOpen && <div className="overlay" onClick={()=>setSettingsOpen(false)}>
        <section className="settings" onClick={e=>e.stopPropagation()}>
          <div className="settings-head"><div><small>ENGINE</small><h2>Configurações</h2></div><button className="icon-btn" onClick={()=>setSettingsOpen(false)}><X/></button></div>
          <div className="settings-grid">
            <Field label="Contexto" value={settings.contextSize} min={512} max={131072} step={512} onChange={v=>setSettings({...settings,contextSize:v})}/>
            <Field label="Threads" value={settings.threads} min={1} max={32} step={1} onChange={v=>setSettings({...settings,threads:v})}/>
            <Field label="Batch" value={settings.batchSize} min={32} max={2048} step={32} onChange={v=>setSettings({...settings,batchSize:v})}/>
            <Field label="GPU layers" value={settings.gpuLayers} min={0} max={999} step={1} onChange={v=>setSettings({...settings,gpuLayers:v})}/>
            <Field label="Temperature" value={settings.temperature} min={0} max={2} step={0.05} onChange={v=>setSettings({...settings,temperature:v})}/>
            <Field label="Top P" value={settings.topP} min={0} max={1} step={0.01} onChange={v=>setSettings({...settings,topP:v})}/>
            <Field label="Top K" value={settings.topK} min={0} max={200} step={1} onChange={v=>setSettings({...settings,topK:v})}/>
            <Field label="Min P" value={settings.minP} min={0} max={1} step={0.01} onChange={v=>setSettings({...settings,minP:v})}/>
            <Field label="Repeat penalty" value={settings.repeatPenalty} min={0.8} max={1.5} step={0.01} onChange={v=>setSettings({...settings,repeatPenalty:v})}/>
          </div>
          <div className="toggles">
            {([['flashAttention','Flash Attention'],['mmap','mmap'],['mlock','mlock'],['numa','NUMA / no-map'],['thinking','Thinking'],['jinja','Jinja / chat template']] as const).map(([key,label])=>
              <label className="toggle" key={key}><span>{label}</span><input type="checkbox" checked={settings[key]} onChange={e=>setSettings({...settings,[key]:e.target.checked})}/><i/></label>
            )}
          </div>
          <div className="note">Algumas opções dependem do backend e da versão do llama.cpp. O app mantém os controles separados da engine para facilitar compatibilidade.</div>
        </section>
      </div>}
    </div>
  );
}

function Field({label,value,min,max,step,onChange}:{label:string,value:number,min:number,max:number,step:number,onChange:(v:number)=>void}) {
  return <label className="field"><span>{label}<b>{value}</b></span><input type="range" min={min} max={max} step={step} value={value} onChange={e=>onChange(Number(e.target.value))}/></label>
}

export default App;
