# PocketPal Local LLM — Android/Capacitor starter

Um app Android nativo com frontend React + Capacitor e uma camada nativa preparada para integrar `llama.cpp`/GGUF.

> Este projeto é uma base funcional de produto: UI, gerenciamento de modelos/configurações, persistência local, bridge Capacitor e pipeline de build estão incluídos. O código nativo usa uma camada `LlamaEngine` isolada para que a versão do `llama.cpp` possa ser atualizada sem reescrever a UI.

## Arquitetura

- `web/` — React + TypeScript + Vite, interface moderna.
- `android/` — projeto Android nativo + Capacitor.
- `android/app/src/main/cpp/` — JNI/C++ e adapter do `llama.cpp`.
- `scripts/` — utilitários de build.
- `.github/workflows/build-android-from-zip.yml` — workflow que extrai o projeto de um ZIP e compila o APK.
- `pocketpal-local-llm.zip` — artefato-base que pode ser colocado no repositório GitHub e usado diretamente pelo workflow.

## Recursos de UI preparados

- chat com streaming visual;
- Markdown/GFM: títulos, negrito/itálico, listas, links, tabelas e blocos de código;
- seletor de modelo;
- importação de GGUF via Storage Access Framework;
- parâmetros: contexto, threads, batch, GPU layers, temperature, top-p, top-k, min-p, repeat penalty;
- opções avançadas: flash attention, mmap, mlock, numa/no-map, seed;
- modo thinking com visualização separada do raciocínio retornado pelo modelo;
- templates Jinja/chat templates;
- persistência local de configurações e conversas;
- tela de informações do modelo;
- suporte inicial a múltiplos perfis/modelos.

## Observação sobre llama.cpp

O build baixa uma versão pinada do `llama.cpp` em CI e a integra por CMake. Isso mantém o ZIP pequeno e evita embutir centenas de MB de código/objetos no projeto.

A implementação nativa é deliberadamente isolada em `LlamaEngineAdapter.cpp`. Assim, mudanças de API do `llama.cpp` ficam confinadas a uma camada.

Consulte `BUILD.md` para o workflow e detalhes de configuração.
