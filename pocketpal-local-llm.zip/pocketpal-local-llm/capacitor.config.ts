import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.localpal.app',
  appName: 'LocalPal',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#0b0d12'
  }
};

export default config;
