# Build no GitHub Actions a partir de um ZIP

O workflow `build-android-from-zip.yml` foi desenhado para o fluxo:

1. você faz commit de **um único ZIP** contendo este projeto;
2. o GitHub Actions baixa o repositório;
3. extrai o ZIP;
4. instala Node, Java, Android SDK/NDK e dependências;
5. baixa a versão pinada do `llama.cpp`;
6. compila a biblioteca nativa para `arm64-v8a`;
7. compila o APK Android;
8. publica o APK como artifact.

## Como usar

Coloque `pocketpal-local-llm.zip` na raiz de um repositório GitHub junto do workflow, por exemplo:

```text
repo/
├── pocketpal-local-llm.zip
└── .github/
    └── workflows/
        └── build-android-from-zip.yml
```

Depois abra **Actions → Build Android from ZIP → Run workflow**.

### Build local

```bash
unzip pocketpal-local-llm.zip -d .
cd pocketpal-local-llm
npm install
npm run build:web
npx cap sync android
cd android
./gradlew assembleDebug
```

## llama.cpp

O workflow usa CMake/NDK para `arm64-v8a`, seguindo a configuração Android recomendada pelo upstream:

- `GGML_NATIVE=OFF`
- `GGML_OPENMP=OFF`
- `GGML_LLAMAFILE=OFF`
- `LLAMA_OPENSSL=OFF`
- `GGML_CPU_KLEIDIAI=ON`

A versão é pinada por commit para tornar builds reproduzíveis. Para atualizar, altere `LLAMA_CPP_REF` no workflow.

## Capacitor

A interface é React e roda dentro do WebView do Capacitor. A inferência não roda no JavaScript: o fluxo é:

```text
React UI
  ↓
Capacitor LocalLlm plugin
  ↓
Kotlin
  ↓
JNI
  ↓
C++ LlamaEngineAdapter
  ↓
llama.cpp / ggml
  ↓
GGUF
```

Isso deixa a UI fácil de evoluir sem misturar o motor de inferência com o frontend.

## Limitações atuais do starter

A API do `llama.cpp` muda com frequência. Por isso, o adapter contém uma área isolada para chamadas de inferência. O restante do app não depende diretamente da API C do llama.cpp.

Para uma release de produção, recomenda-se:

- fixar um commit conhecido do `llama.cpp`;
- validar cada arquitetura de dispositivo;
- adicionar testes JNI;
- implementar cancelamento cooperativo durante a geração;
- adicionar gerenciamento de memória/eviction de modelos;
- adicionar suporte a multimodalidade quando necessário;
- assinar o APK/AAB no CI.

## Licença

A UI e o código deste starter podem ser usados como base. `llama.cpp` possui licença própria e deve ser tratado separadamente.
