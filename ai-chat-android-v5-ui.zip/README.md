# AI Chat Android — v5

Chat local Android usando llama.cpp e modelos GGUF.

## Nesta versão

- Interface dark minimalista em preto/cinza/branco.
- Composer moderno com campo multilinha e botão de envio.
- Anexos de arquivos de texto/código/JSON/Markdown/CSV/log (até 256 KB).
- Menu lateral de conversas em memória.
- Nova conversa e troca entre conversas.
- Bolhas de mensagem para usuário/IA.
- Streaming de tokens.
- Contador de tokens e tokens por segundo.
- Template de chat obtido do próprio GGUF via `llama_chat_apply_template`.
- Continua usando somente `arm64-v8a`.

### Anexos

O modelo atual é textual, então os anexos são lidos como UTF-8 e incluídos no prompt. Imagens e PDFs binários ainda não são interpretados pelo modelo.

## Build

O workflow separado continua sendo usado para baixar a versão do llama.cpp, compilar e assinar o APK.
