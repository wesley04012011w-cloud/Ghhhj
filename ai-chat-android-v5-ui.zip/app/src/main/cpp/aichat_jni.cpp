#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <chrono>
#include "llama.h"

struct Engine {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    std::mutex mutex;
};

static std::string jstring_to_string(JNIEnv *env, jstring s) {
    if (!s) return {};
    const char *p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}

static void callback_error(JNIEnv *env, jobject callback, const std::string & message) {
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onError", "(Ljava/lang/String;)V");
    if (method) {
        jstring msg = env->NewStringUTF(message.c_str());
        env->CallVoidMethod(callback, method, msg);
        env->DeleteLocalRef(msg);
    }
    env->DeleteLocalRef(cls);
}

static void callback_token(JNIEnv *env, jobject callback, const std::string & piece) {
    if (piece.empty()) return;
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onToken", "(Ljava/lang/String;)V");
    if (method) {
        jstring token = env->NewStringUTF(piece.c_str());
        env->CallVoidMethod(callback, method, token);
        env->DeleteLocalRef(token);
    }
    env->DeleteLocalRef(cls);
}

static void callback_complete(JNIEnv *env, jobject callback) {
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onComplete", "()V");
    if (method) env->CallVoidMethod(callback, method);
    env->DeleteLocalRef(cls);
}

static void callback_stats(
    JNIEnv *env,
    jobject callback,
    int generated_tokens,
    int prompt_tokens,
    double tokens_per_second
) {
    jclass cls = env->GetObjectClass(callback);
    if (!cls) return;
    jmethodID method = env->GetMethodID(cls, "onStats", "(IID)V");
    if (method) {
        env->CallVoidMethod(
            callback,
            method,
            static_cast<jint>(generated_tokens),
            static_cast<jint>(prompt_tokens),
            static_cast<jdouble>(tokens_per_second)
        );
    }
    env->DeleteLocalRef(cls);
}

static bool apply_chat_template(
    llama_model * model,
    const std::vector<std::string> & roles,
    const std::vector<std::string> & contents,
    std::string & formatted
) {
    const char * tmpl = llama_model_chat_template(model, nullptr);

    std::vector<llama_chat_message> messages;
    messages.reserve(roles.size());

    for (size_t i = 0; i < roles.size(); ++i) {
        messages.push_back({
            roles[i].c_str(),
            contents[i].c_str()
        });
    }

    int32_t len = llama_chat_apply_template(
        tmpl,
        messages.data(),
        messages.size(),
        true,
        nullptr,
        0
    );

    if (len < 0) return false;

    std::vector<char> buffer(static_cast<size_t>(len) + 1, '\0');

    int32_t written = llama_chat_apply_template(
        tmpl,
        messages.data(),
        messages.size(),
        true,
        buffer.data(),
        static_cast<int32_t>(buffer.size())
    );

    if (written < 0) return false;

    formatted.assign(buffer.data(), static_cast<size_t>(written));
    return true;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_aichat_LlamaEngine_nativeCreate(JNIEnv*, jobject) {
    llama_backend_init();
    auto *e = new Engine();
    return reinterpret_cast<jlong>(e);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_aichat_LlamaEngine_nativeLoad(JNIEnv *env, jobject,
                                                jlong handle, jstring path) {
    auto *e = reinterpret_cast<Engine*>(handle);
    if (!e) return JNI_FALSE;

    std::lock_guard<std::mutex> lock(e->mutex);

    if (e->ctx) {
        llama_free(e->ctx);
        e->ctx = nullptr;
    }
    if (e->model) {
        llama_model_free(e->model);
        e->model = nullptr;
    }

    llama_model_params mp = llama_model_default_params();
    std::string p = jstring_to_string(env, path);
    e->model = llama_model_load_from_file(p.c_str(), mp);
    if (!e->model) return JNI_FALSE;

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 4096;
    cp.n_batch = 512;
    cp.n_threads = 0;
    cp.n_threads_batch = 0;

    e->ctx = llama_init_from_model(e->model, cp);
    if (!e->ctx) {
        llama_model_free(e->model);
        e->model = nullptr;
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_aichat_LlamaEngine_nativeGenerateStreaming(
    JNIEnv *env,
    jobject,
    jlong handle,
    jobjectArray jroles,
    jobjectArray jcontents,
    jobject callback
) {
    auto *e = reinterpret_cast<Engine*>(handle);
    if (!e || !callback) return;

    std::lock_guard<std::mutex> lock(e->mutex);

    if (!e->model || !e->ctx) {
        callback_error(env, callback, "Modelo não carregado.");
        return;
    }

    const jsize role_count = env->GetArrayLength(jroles);
    const jsize content_count = env->GetArrayLength(jcontents);

    if (role_count <= 0 || role_count != content_count) {
        callback_error(env, callback, "Histórico de conversa inválido.");
        return;
    }

    std::vector<std::string> roles;
    std::vector<std::string> contents;
    roles.reserve(role_count);
    contents.reserve(content_count);

    for (jsize i = 0; i < role_count; ++i) {
        auto role = static_cast<jstring>(env->GetObjectArrayElement(jroles, i));
        auto content = static_cast<jstring>(env->GetObjectArrayElement(jcontents, i));

        roles.push_back(jstring_to_string(env, role));
        contents.push_back(jstring_to_string(env, content));

        if (role) env->DeleteLocalRef(role);
        if (content) env->DeleteLocalRef(content);
    }

    std::string prompt;
    if (!apply_chat_template(e->model, roles, contents, prompt)) {
        callback_error(env, callback,
                       "Não foi possível aplicar o template de conversa deste modelo.");
        return;
    }

    const llama_vocab *vocab = llama_model_get_vocab(e->model);

    const int n_prompt = -llama_tokenize(
        vocab,
        prompt.c_str(),
        prompt.size(),
        nullptr,
        0,
        true,
        true
    );

    if (n_prompt <= 0) {
        callback_error(env, callback, "Não consegui tokenizar o prompt.");
        return;
    }

    std::vector<llama_token> tokens(static_cast<size_t>(n_prompt));

    if (llama_tokenize(
            vocab,
            prompt.c_str(),
            prompt.size(),
            tokens.data(),
            tokens.size(),
            true,
            true
        ) < 0) {
        callback_error(env, callback, "Falha ao tokenizar o prompt.");
        return;
    }

    llama_memory_clear(llama_get_memory(e->ctx), true);

    llama_batch batch = llama_batch_init(512, 0, 1);

    if (tokens.size() > 512) {
        llama_batch_free(batch);
        callback_error(env, callback,
                       "O prompt ficou grande demais para o lote atual.");
        return;
    }

    for (size_t i = 0; i < tokens.size(); ++i) {
        batch.token[i] = tokens[i];
        batch.pos[i] = static_cast<llama_pos>(i);
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == tokens.size() - 1);
    }
    batch.n_tokens = static_cast<int32_t>(tokens.size());

    if (llama_decode(e->ctx, batch) != 0) {
        llama_batch_free(batch);
        callback_error(env, callback, "Falha no decode inicial.");
        return;
    }

    llama_sampler_chain_params sp = llama_sampler_chain_default_params();
    llama_sampler *sampler = llama_sampler_chain_init(sp);

    if (!sampler) {
        llama_batch_free(batch);
        callback_error(env, callback, "Falha ao criar o sampler.");
        return;
    }

    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    int cur_pos = static_cast<int>(tokens.size());
    const int max_new_tokens = 512;
    int generated_tokens = 0;
    const auto generation_start = std::chrono::steady_clock::now();

    for (int i = 0; i < max_new_tokens; ++i) {
        llama_token token = llama_sampler_sample(sampler, e->ctx, -1);

        if (llama_vocab_is_eog(vocab, token)) {
            break;
        }

        char piece[1024];
        int len = llama_token_to_piece(
            vocab,
            token,
            piece,
            sizeof(piece),
            0,
            true
        );

        if (len > 0) {
            callback_token(env, callback, std::string(piece, len));
        }

        llama_sampler_accept(sampler, token);
        ++generated_tokens;

        const auto elapsed = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - generation_start
        ).count();
        const double tps = elapsed > 0.0
            ? static_cast<double>(generated_tokens) / elapsed
            : 0.0;
        callback_stats(env, callback, generated_tokens, n_prompt, tps);

        batch.n_tokens = 1;
        batch.token[0] = token;
        batch.pos[0] = cur_pos++;
        batch.n_seq_id[0] = 1;
        batch.seq_id[0][0] = 0;
        batch.logits[0] = true;

        if (llama_decode(e->ctx, batch) != 0) {
            llama_sampler_free(sampler);
            llama_batch_free(batch);
            callback_error(env, callback, "Falha durante a geração.");
            return;
        }
    }

    llama_sampler_free(sampler);
    llama_batch_free(batch);

    callback_complete(env, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_aichat_LlamaEngine_nativeDestroy(JNIEnv*, jobject, jlong handle) {
    auto *e = reinterpret_cast<Engine*>(handle);
    if (!e) return;

    std::lock_guard<std::mutex> lock(e->mutex);

    if (e->ctx) llama_free(e->ctx);
    if (e->model) llama_model_free(e->model);

    llama_backend_free();
    delete e;
}
