package com.example.aichat

import android.content.Context

class LlamaEngine(context: Context) {
    interface StreamCallback {
        fun onToken(token: String)
        fun onComplete()
        fun onError(message: String)
        fun onStats(generatedTokens: Int, promptTokens: Int, tokensPerSecond: Double)
    }

    companion object {
        init {
            System.loadLibrary("aichat")
        }
    }

    private val handle: Long = nativeCreate()

    fun load(path: String) {
        check(nativeLoad(handle, path)) {
            "Não foi possível carregar o modelo."
        }
    }

    fun generateStreaming(
        messages: List<Pair<String, String>>,
        callback: StreamCallback
    ) {
        val roles = messages.map { it.first }.toTypedArray()
        val contents = messages.map { it.second }.toTypedArray()

        nativeGenerateStreaming(handle, roles, contents, callback)
    }

    protected fun finalize() {
        nativeDestroy(handle)
    }

    private external fun nativeCreate(): Long

    private external fun nativeLoad(
        handle: Long,
        path: String
    ): Boolean

    private external fun nativeGenerateStreaming(
        handle: Long,
        roles: Array<String>,
        contents: Array<String>,
        callback: StreamCallback
    )

    private external fun nativeDestroy(handle: Long)
}
