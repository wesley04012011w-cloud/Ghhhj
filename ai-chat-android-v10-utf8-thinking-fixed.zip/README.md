# AI Chat Android — v0.4

Chat local Android com `llama.cpp` + GGUF.

## O que mudou nesta versão

- UI dark sem exagero de cores.
- Conteúdo respeita status bar, navigation bar e IME/teclado via WindowInsets.
- Composer continua visível quando o teclado Samsung/Android abre.
- Menu lateral com conversas e acesso a **Configurações da engine**.
- Configurações persistentes:
  - contexto;
  - batch;
  - threads CPU;
  - MMAP;
  - Flash Attention;
  - tipo de KV cache (F16/Q8_0/Q4_0);
  - temperatura;
  - Top-K;
  - Top-P;
  - Min-P;
  - repetição;
  - repeat-last-N;
  - máximo de tokens;
  - seed.
- Alterações de engine são aplicadas ao recarregar o modelo.
- Streaming e chat template do GGUF continuam ativos.

As opções de contexto, KV cache e Flash Attention correspondem aos parâmetros atuais expostos pelo `llama.cpp`; tipos KV quantizados exigem Flash Attention. A documentação upstream também expõe batch, threads, temperatura, Top-K, Top-P, Min-P e penalidade de repetição como parâmetros de execução. 


V9: chat templates agora usam a camada common_chat do llama.cpp com Jinja e enable_thinking=true; o parser de reasoning usa as tags detectadas pelo template. Defaults de amostragem foram ajustados para 0.6 / top-k 20 / min-p 0.0.


V9: corrige o estado inicial do parser de thinking quando o template já injeta `<think>` no prompt, remove o overload legado do chat template, aumenta o buffer de peça de token e deixa a penalidade de repetição desligada por padrão (1.0).

V10 fixes UTF-8 token chunks crossing JNI boundaries and strengthens Qwen3 reasoning tag detection.
