package com.aichat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.BaseActivityEventListener
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.modules.core.DeviceEventManagerModule
import java.io.File

class AIChatModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    companion object {
        const val NAME = "AIChat"
        const val PICK = 7301
    }

    private val engine = LlamaEngine(reactContext)
    private var pickPromise: Promise? = null
    private var loadedPath: String? = null

    private val activityEventListener = object : BaseActivityEventListener() {
        override fun onActivityResult(
            activity: Activity,
            requestCode: Int,
            resultCode: Int,
            data: Intent?
        ) {
            handleModelPickerResult(requestCode, resultCode, data)
        }
    }

    init {
        reactContext.addActivityEventListener(activityEventListener)
    }

    override fun getName() = NAME

    private fun emit(map: com.facebook.react.bridge.WritableMap) {
        reactContext.getJSModule(
            DeviceEventManagerModule.RCTDeviceEventEmitter::class.java
        ).emit("AIChatStream", map)
    }

    private fun event(type: String): com.facebook.react.bridge.WritableMap =
        Arguments.createMap().apply { putString("type", type) }

    @ReactMethod
    fun pickModel(promise: Promise) {
        val activity = getCurrentActivity()
        if (activity == null) {
            promise.reject("NO_ACTIVITY", "Activity indisponível")
            return
        }

        pickPromise = promise
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }

        try {
            activity.startActivityForResult(intent, PICK)
        } catch (e: Exception) {
            pickPromise = null
            promise.reject("PICK_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun listModels(promise: Promise) {
        try {
            val dir = File(reactContext.filesDir, "models").apply { mkdirs() }
            val arr = Arguments.createArray()
            dir.listFiles()
                ?.filter { it.isFile && it.name.endsWith(".gguf", true) }
                ?.sortedBy { it.name }
                ?.forEach { arr.pushString(it.absolutePath) }
            promise.resolve(arr)
        } catch (e: Exception) {
            promise.reject("LIST_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun loadModel(path: String, promise: Promise) {
        try {
            engine.load(path, EngineSettings.from(reactContext))
            loadedPath = path
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("LOAD_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun unloadModel(promise: Promise) {
        try {
            engine.unload()
            loadedPath = null
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("UNLOAD_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun generate(messages: com.facebook.react.bridge.ReadableArray, promise: Promise) {
        val path = loadedPath
        if (path == null) {
            promise.reject("NO_MODEL", "Carregue um modelo primeiro")
            return
        }

        try {
            val list = ArrayList<Pair<String, String>>()
            for (i in 0 until messages.size()) {
                val m = messages.getMap(i) ?: continue
                list.add(
                    (m.getString("role") ?: "user") to
                    (m.getString("content") ?: "")
                )
            }

            Thread {
                try {
                    engine.generateStreaming(list, object : LlamaEngine.StreamCallback {
                        override fun onToken(token: String) {
                            emit(event("token").apply { putString("token", token) })
                        }

                        override fun onThinkingStart() {
                            emit(event("thinkingStart"))
                        }

                        override fun onComplete() {
                            emit(event("complete"))
                            promise.resolve(true)
                        }

                        override fun onError(message: String) {
                            emit(event("error").apply { putString("message", message) })
                            promise.reject("GENERATION_FAILED", message)
                        }

                        override fun onStats(
                            generatedTokens: Int,
                            promptTokens: Int,
                            tokensPerSecond: Double
                        ) {
                            emit(event("stats").apply {
                                putInt("generatedTokens", generatedTokens)
                                putInt("promptTokens", promptTokens)
                                putDouble("tokensPerSecond", tokensPerSecond)
                            })
                        }
                    })
                } catch (e: Exception) {
                    emit(event("error").apply {
                        putString("message", e.message ?: "Erro na geração")
                    })
                    promise.reject("GENERATION_FAILED", e.message, e)
                }
            }.start()
        } catch (e: Exception) {
            promise.reject("GENERATION_FAILED", e.message, e)
        }
    }

    private fun handleModelPickerResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        if (requestCode != PICK) return

        val promise = pickPromise
        pickPromise = null

        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            promise?.resolve(null)
            return
        }

        try {
            val uri = data.data!!
            val dir = File(reactContext.filesDir, "models").apply { mkdirs() }
            val name = queryName(uri) ?: "model_${System.currentTimeMillis()}.gguf"
            val safe = name.substringAfterLast('/').ifBlank { "model.gguf" }
            val out = File(dir, safe)

            reactContext.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Não foi possível abrir o arquivo" }
                out.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            promise?.resolve(out.absolutePath)
        } catch (e: Exception) {
            promise?.reject("IMPORT_FAILED", e.message, e)
        }
    }

    private fun queryName(uri: Uri): String? =
        reactContext.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
}
