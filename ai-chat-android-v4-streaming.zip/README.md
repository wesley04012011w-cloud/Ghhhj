# AI Chat Android v3

Base Android de chat local com Kotlin + JNI/C++ + llama.cpp.

## O que o app faz

- Usuário escolhe um modelo `.gguf` pelo seletor de arquivos do Android.
- O arquivo é copiado para o armazenamento privado do app.
- O modelo é carregado pela engine nativa.
- A geração roda localmente, sem servidor.

## ABI

O projeto está configurado para `arm64-v8a`, o alvo Android recomendado pelo llama.cpp para esse caminho de build. O build usa `GGML_NATIVE=OFF`, `GGML_OPENMP=OFF`, `GGML_LLAMAFILE=OFF` e KleidiAI.

## Build pelo repositório externo

O ZIP não contém o workflow. No repositório GitHub externo:

```text
/
├── ai-chat-android-v3.zip
└── .github/
    └── workflows/
        └── build-from-zip.yml
```

O workflow extrai o ZIP, instala as dependências Android necessárias, baixa o llama.cpp na tag fixada e produz o APK em Actions > Artifacts.

## Próximos upgrades

A base atual é propositalmente pequena. Depois do primeiro APK funcionando, o ideal é adicionar:

- streaming token a token;
- histórico de conversa;
- system prompt;
- seleção de contexto;
- threads/batch;
- lista de modelos importados;
- exclusão/gerenciamento de modelos;
- Jetpack Compose;
- persistência de chats.


## v0.2.0

- Usa o chat template armazenado no GGUF via `llama_chat_apply_template`.
- Histórico de conversa com mensagens system/user/assistant.
- Streaming de tokens do JNI para Kotlin.
- Interface renovada e botão para limpar a conversa.
