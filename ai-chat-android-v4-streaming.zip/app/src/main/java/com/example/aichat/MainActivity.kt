package com.example.aichat

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var engine: LlamaEngine
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var importButton: Button
    private lateinit var clearButton: Button

    private var modelFile: File? = null
    private var generating = false

    private val history = mutableListOf<Pair<String, String>>()
    private val systemPrompt =
        "Você é um assistente útil, direto e amigável. Responda no idioma usado pelo usuário. " +
        "Não invente informações quando não souber."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        engine = LlamaEngine(this)
        buildUi()
    }

    private fun buildUi() {
        val bg = Color.rgb(24, 24, 24)
        val panel = Color.rgb(38, 38, 38)
        val accent = Color.rgb(128, 220, 215)
        val text = Color.rgb(238, 238, 238)
        val muted = Color.rgb(170, 170, 170)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 12)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            this.text = "AI Chat"
            textSize = 25f
            setTextColor(text)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(4, 2, 4, 2)
        }

        val subtitle = TextView(this).apply {
            this.text = "llama.cpp • conversa local"
            textSize = 13f
            setTextColor(muted)
            setPadding(4, 0, 4, 12)
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        importButton = Button(this).apply {
            this.text = "IMPORTAR GGUF"
            isAllCaps = false
            setOnClickListener { pickModel() }
        }

        clearButton = Button(this).apply {
            this.text = "Limpar"
            isAllCaps = false
            setOnClickListener { clearConversation() }
        }

        topRow.addView(importButton, LinearLayout.LayoutParams(0, -2, 1f))
        topRow.addView(clearButton, LinearLayout.LayoutParams(-2, -2))

        status = TextView(this).apply {
            this.text = "Nenhum modelo carregado"
            textSize = 14f
            setTextColor(accent)
            setPadding(8, 10, 8, 10)
            setBackgroundColor(panel)
        }

        chat = TextView(this).apply {
            this.text = "Importe um modelo GGUF para começar."
            textSize = 16f
            setTextColor(text)
            setPadding(14, 14, 14, 14)
            setLineSpacing(0f, 1.08f)
            setBackgroundColor(panel)
            isVerticalScrollBarEnabled = false
        }

        chatScroll = ScrollView(this).apply {
            isFillViewport = true
            addView(chat, ScrollView.LayoutParams(-1, -2))
        }

        input = EditText(this).apply {
            hint = "Digite sua mensagem..."
            setTextColor(text)
            setHintTextColor(Color.rgb(125, 125, 125))
            setSingleLine(false)
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(14, 12, 14, 12)
            setBackgroundColor(panel)
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else {
                false
            }
        }

        send = Button(this).apply {
            this.text = "ENVIAR"
            textSize = 15f
            isAllCaps = false
            setOnClickListener { sendMessage() }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(topRow)
        root.addView(status)

        root.addView(
            chatScroll,
            LinearLayout.LayoutParams(-1, 0, 1f).apply {
                topMargin = 10
                bottomMargin = 10
            }
        )

        root.addView(input)
        root.addView(
            send,
            LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = 8
            }
        )

        setContentView(root)
    }

    private fun pickModel() {
        if (generating) return

        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/octet-stream"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100 || resultCode != RESULT_OK) return

        val uri = data?.data ?: return

        Thread {
            try {
                val name = queryName(uri) ?: "model.gguf"
                val dst = File(filesDir, "models/$name")
                dst.parentFile?.mkdirs()

                contentResolver.openInputStream(uri).use { inputStream ->
                    requireNotNull(inputStream) { "Não consegui abrir o arquivo." }
                    FileOutputStream(dst).use { output ->
                        inputStream.copyTo(output, 1024 * 1024)
                    }
                }

                runOnUiThread {
                    status.text = "Carregando: $name"
                    chat.text = "Carregando o modelo..."
                    setControlsEnabled(false)
                }

                engine.load(dst.absolutePath)

                runOnUiThread {
                    modelFile = dst
                    history.clear()
                    status.text = "✓ Modelo carregado: $name"
                    chat.text = "Pronto. Pode conversar."
                    setControlsEnabled(true)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Erro ao carregar: ${e.message ?: "desconhecido"}"
                    setControlsEnabled(true)
                }
            }
        }.start()
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()

        if (prompt.isEmpty() || generating) return

        if (modelFile == null) {
            status.text = "Importe um modelo primeiro."
            return
        }

        input.setText("")
        generating = true
        setControlsEnabled(false)

        history.add("user" to prompt)
        appendMessage("Você", prompt)
        appendRaw("\nIA: ")

        val messages = mutableListOf<Pair<String, String>>()
        messages.add("system" to systemPrompt)
        messages.addAll(history)

        val answer = StringBuilder()

        Thread {
            try {
                engine.generateStreaming(
                    messages,
                    object : LlamaEngine.StreamCallback {
                        override fun onToken(token: String) {
                            answer.append(token)
                            runOnUiThread {
                                appendRaw(token)
                                scrollToBottom()
                            }
                        }

                        override fun onComplete() {
                            history.add("assistant" to answer.toString())
                            runOnUiThread {
                                generating = false
                                setControlsEnabled(true)
                                status.text = "✓ Pronto"
                                scrollToBottom()
                            }
                        }

                        override fun onError(message: String) {
                            if (history.lastOrNull()?.first == "user") {
                                history.removeAt(history.lastIndex)
                            }

                            runOnUiThread {
                                appendRaw("\n[erro: $message]")
                                generating = false
                                setControlsEnabled(true)
                                status.text = "Erro na geração"
                                scrollToBottom()
                            }
                        }
                    }
                )
            } catch (e: Exception) {
                if (history.lastOrNull()?.first == "user") {
                    history.removeAt(history.lastIndex)
                }

                runOnUiThread {
                    appendRaw("\n[erro: ${e.message ?: "desconhecido"}]")
                    generating = false
                    setControlsEnabled(true)
                }
            }
        }.start()
    }

    private fun appendMessage(label: String, message: String) {
        if (chat.text.isNotEmpty() &&
            chat.text.toString() != "Pronto. Pode conversar." &&
            chat.text.toString() != "Importe um modelo GGUF para começar."
        ) {
            chat.append("\n\n")
        }

        chat.append("$label: $message")
    }

    private fun appendRaw(value: String) {
        chat.append(value)
    }

    private fun clearConversation() {
        if (generating) return

        history.clear()
        chat.text = if (modelFile != null) {
            "Conversa limpa. Pode mandar a próxima mensagem."
        } else {
            "Importe um modelo GGUF para começar."
        }
        scrollToBottom()
    }

    private fun setControlsEnabled(enabled: Boolean) {
        importButton.isEnabled = enabled
        clearButton.isEnabled = enabled
        input.isEnabled = enabled
        send.isEnabled = enabled
    }

    private fun scrollToBottom() {
        chatScroll.post {
            chatScroll.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }

        return uri.lastPathSegment?.substringAfterLast('/')
    }

    override fun onDestroy() {
        super.onDestroy()
        // Native resources are released by LlamaEngine.finalize().
    }
}
