# AI Chat — React Native + llama.cpp

Primeira migração da interface para React Native, mantendo o motor local llama.cpp em C++.

## Versões fixadas
- React Native 0.87.0 (release estável ativa em setembro de 2026)
- React 19.2.0
- React Native CLI 20.2.0
- Node 22.13.1 no CI
- JDK 17 no CI
- Gradle 9.1.0 no CI
- Android Gradle Plugin 9 via React Native 0.87
- Kotlin 2.2.0
- compileSdk 37 / buildTools 37.0.0
- NDK 27.1.12297006
- CMake 3.31.6
- ABI somente arm64-v8a

## Sem SVG
Esta versão não adiciona `react-native-svg` nem biblioteca de ícones SVG. Os ícones principais são desenhados com Views nativas do React Native, para evitar a classe de problemas de SVG/dependências que tivemos antes.

## Motor
O `LlamaEngine.kt` e `aichat_jni.cpp` foram reaproveitados da versão Android anterior. O JNI foi ajustado para o pacote `com.aichat`.

Antes do build:

```bash
./scripts/fetch-llama.sh
npm install
cd android
./gradlew :app:assembleRelease
```

No CI, o Gradle 9.1 é instalado pelo workflow e o projeto é construído para arm64-v8a.

## Estado da V1
- UI React Native escura e moderna
- Composer compacto
- botão + e enviar
- seleção/importação de GGUF
- listagem de modelos locais
- load/unload via módulo nativo
- streaming nativo via eventos para JS
- estrutura preparada para Markdown/Thinking/settings nas próximas telas

A lógica visual de Thinking/Markdown ainda é propositalmente mínima nesta primeira migração para reduzir a superfície de bugs antes de portar os recursos restantes.


Build note: Android compile/target SDK is aligned to API 36 for the GitHub Actions runner.
