package com.example.aichat

import android.content.Context

data class EngineSettings(
    val contextSize: Int = 4096,
    val batchSize: Int = 512,
    val threads: Int = 0,
    val mmap: Boolean = true,
    val flashAttention: Int = -1, // -1 auto, 0 off, 1 on
    val kvType: String = "F16",
    val temperature: Float = 0.6f,
    val topK: Int = 20,
    val topP: Float = 0.95f,
    val minP: Float = 0.0f,
    val repeatPenalty: Float = 1.0f,
    val repeatLastN: Int = 64,
    val maxTokens: Int = 512,
    val seed: Long = -1L,
    val useJinja: Boolean = true,
    val enableThinking: Boolean = true
) {
    companion object {
        const val PREFS = "engine_settings"

        fun from(context: Context): EngineSettings {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val ctx = p.getInt("context", 4096)
            val batch = p.getInt("batch", 512).coerceAtMost(ctx)
            return EngineSettings(
                contextSize = ctx,
                batchSize = batch,
                threads = p.getInt("threads", 0),
                mmap = p.getBoolean("mmap", true),
                flashAttention = p.getInt("flash", -1),
                kvType = p.getString("kv", "F16") ?: "F16",
                temperature = p.getFloat("temperature", 0.6f),
                topK = p.getInt("top_k", 20),
                topP = p.getFloat("top_p", 0.95f),
                minP = p.getFloat("min_p", 0.0f),
                repeatPenalty = p.getFloat("repeat_penalty", 1.0f),
                repeatLastN = p.getInt("repeat_last_n", 64),
                maxTokens = p.getInt("max_tokens", 512),
                seed = p.getLong("seed", -1L),
                useJinja = p.getBoolean("use_jinja", true),
                enableThinking = p.getBoolean("enable_thinking", true)
            )
        }

        fun save(context: Context, s: EngineSettings) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putInt("context", s.contextSize)
                .putInt("batch", s.batchSize.coerceAtMost(s.contextSize))
                .putInt("threads", s.threads)
                .putBoolean("mmap", s.mmap)
                .putInt("flash", s.flashAttention)
                .putString("kv", s.kvType)
                .putFloat("temperature", s.temperature)
                .putInt("top_k", s.topK)
                .putFloat("top_p", s.topP)
                .putFloat("min_p", s.minP)
                .putFloat("repeat_penalty", s.repeatPenalty)
                .putInt("repeat_last_n", s.repeatLastN)
                .putInt("max_tokens", s.maxTokens)
                .putLong("seed", s.seed)
                .putBoolean("use_jinja", s.useJinja)
                .putBoolean("enable_thinking", s.enableThinking)
                .apply()
        }
    }
}

class LlamaEngine(private val context: Context) {
    interface StreamCallback {
        // Keep every callback abstract. The native JNI bridge looks these methods
        // up on the concrete callback object; Kotlin default interface methods can
        // live on the interface itself and therefore are not reliably discoverable
        // through JNI GetMethodID().
        fun onToken(token: String)
        fun onThinkingStart()
        fun onComplete()
        fun onError(message: String)
        fun onStats(generatedTokens: Int, promptTokens: Int, tokensPerSecond: Double)
    }

    companion object {
        init {
            System.loadLibrary("aichat")
        }
    }

    private val handle: Long = nativeCreate()

    fun load(path: String, settings: EngineSettings = EngineSettings.from(context)) {
        check(
            nativeLoad(
                handle,
                path,
                settings.contextSize,
                settings.batchSize.coerceAtMost(settings.contextSize),
                settings.threads,
                settings.mmap,
                settings.flashAttention,
                settings.kvType,
                settings.temperature,
                settings.topK,
                settings.topP,
                settings.minP,
                settings.repeatPenalty,
                settings.repeatLastN,
                settings.maxTokens,
                settings.seed
            )
        ) {
            "Não foi possível carregar o modelo."
        }
    }

    fun generateStreaming(
        messages: List<Pair<String, String>>,
        callback: StreamCallback,
        settings: EngineSettings = EngineSettings.from(context)
    ) {
        val roles = messages.map { it.first }.toTypedArray()
        val contents = messages.map { it.second }.toTypedArray()
        nativeGenerateStreaming(handle, roles, contents, settings.useJinja, settings.enableThinking, callback)
    }

    fun unload() { nativeUnload(handle) }

    protected fun finalize() {
        nativeDestroy(handle)
    }

    private external fun nativeCreate(): Long

    private external fun nativeLoad(
        handle: Long,
        path: String,
        contextSize: Int,
        batchSize: Int,
        threads: Int,
        mmap: Boolean,
        flashAttention: Int,
        kvType: String,
        temperature: Float,
        topK: Int,
        topP: Float,
        minP: Float,
        repeatPenalty: Float,
        repeatLastN: Int,
        maxTokens: Int,
        seed: Long
    ): Boolean

    private external fun nativeGenerateStreaming(
        handle: Long,
        roles: Array<String>,
        contents: Array<String>,
        useJinja: Boolean,
        enableThinking: Boolean,
        callback: StreamCallback
    )

    private external fun nativeUnload(handle: Long)

    private external fun nativeDestroy(handle: Long)
}
