package com.example.aichat

import android.graphics.Typeface
import android.text.Html
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.widget.TextView
import java.util.regex.Pattern

object MarkdownRenderer {
    private const val CODE_BG = 0xFF171717.toInt()
    private const val CODE_FG = 0xFFE8E8E8.toInt()

    fun render(text: String): Spanned {
        var s = escape(text)

        // Fenced code blocks first.
        val codePattern = Pattern.compile("(?s)```(?:[\\w+.-]+)?\\n?(.*?)```")
        val matcher = codePattern.matcher(s)
        val codes = mutableListOf<String>()
        val sb = StringBuffer()
        while (matcher.find()) {
            val index = codes.size
            codes += matcher.group(1) ?: ""
            matcher.appendReplacement(sb, "§§CODE$index§§")
        }
        matcher.appendTail(sb)
        s = sb.toString()

        // Tables: consecutive markdown rows with a separator row.
        val lines = s.split("\n").toMutableList()
        val out = StringBuilder()
        var i = 0
        while (i < lines.size) {
            if (i + 1 < lines.size && isTableSeparator(lines[i + 1])) {
                val header = splitTableRow(lines[i])
                val separator = splitTableRow(lines[i + 1])
                if (header.isNotEmpty() && separator.size == header.size) {
                    out.append("<br><b>")
                    out.append(header.joinToString("  |  "))
                    out.append("</b><br>")
                    out.append(header.joinToString("  |  ") { "—".repeat(maxOf(3, it.length.coerceAtMost(12))) })
                    out.append("<br>")
                    i += 2
                    while (i < lines.size && lines[i].contains("|")) {
                        val cells = splitTableRow(lines[i])
                        if (cells.size != header.size) break
                        out.append(cells.joinToString("  |  ")).append("<br>")
                        i++
                    }
                    out.append("<br>\n")
                    continue
                }
            }
            out.append(lines[i]).append("\n")
            i++
        }
        s = out.toString()

        // Headings.
        s = s.replace(Regex("(?m)^###### (.+)$"), "<b><small>$1</small></b>")
            .replace(Regex("(?m)^##### (.+)$"), "<b>$1</b>")
            .replace(Regex("(?m)^#### (.+)$"), "<b>$1</b>")
            .replace(Regex("(?m)^### (.+)$"), "<b><big>$1</big></b>")
            .replace(Regex("(?m)^## (.+)$"), "<b><big>$1</big></b>")
            .replace(Regex("(?m)^# (.+)$"), "<b><big>$1</big></b>")

        // Lists.
        s = s.replace(Regex("(?m)^\\s*[-*] (.+)$"), "• $1")
        s = s.replace(Regex("(?m)^\\s*(\\d+)\\. (.+)$"), "$1. $2")

        // Blockquotes.
        s = s.replace(Regex("(?m)^&gt; ?(.+)$"), "<font color=\"#A0A0A0\">▌ $1</font>")

        // Inline code, bold, strike and italic.
        s = s.replace(Regex("`([^`]+)`"), "<font color=\"#E8E8E8\"><b>$1</b></font>")
        s = s.replace(Regex("\\*\\*([^*]+)\\*\\*|__([^_]+)__")) { m ->
            "<b>${m.groupValues[1].ifEmpty { m.groupValues[2] }}</b>"
        }
        s = s.replace(Regex("~~([^~]+)~~"), "<s>$1</s>")
        s = s.replace(Regex("(?<!\\*)\\*([^*]+)\\*(?!\\*)|(?<!_)_([^_]+)_(?!_)")) { m ->
            "<i>${m.groupValues[1].ifEmpty { m.groupValues[2] }}</i>"
        }

        // Preserve newlines as HTML line breaks.
        s = s.replace("\n", "<br>")

        codes.forEachIndexed { index, code ->
            val safe = code.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\n", "<br>")
            s = s.replace("§§CODE$index§§", "<font color=\"#E8E8E8\"><b>$safe</b></font>")
        }

        return Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY)
    }

    fun apply(view: TextView, text: String) {
        view.text = render(text)
    }

    private fun escape(text: String): String =
        text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun splitTableRow(line: String): List<String> =
        line.trim().trim('|').split("|").map { it.trim() }

    private fun isTableSeparator(line: String): Boolean =
        line.contains("|") && splitTableRow(line).all { it.matches(Regex(":?-{3,}:?")) }
}
